import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        // Design tokens — see DESIGN.md for rationale.
        "court-navy": "#0A1930",
        "court-blue": "#142A4D",
        "court-blue-light": "#1E3A63",
        chalk: "#F4F6F9",
        steel: "#7C8CA6",
        "match-point": "#FF6B35",
        "match-point-dim": "#B84E27",
        ace: "#3ECF8E",
      },
      fontFamily: {
        display: ["'Bebas Neue'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
} satisfies Config;
