interface ErrorBannerProps {
  message: string;
}

export default function ErrorBanner({ message }: ErrorBannerProps) {
  return (
    <div className="rounded-lg border border-match-point-dim bg-match-point/10 px-4 py-3 text-sm text-chalk">
      <span className="font-semibold text-match-point">Couldn't load this. </span>
      {message}
    </div>
  );
}
