interface StatCardProps {
  label: string;
  value: string | number;
  sublabel?: string;
}

export default function StatCard({ label, value, sublabel }: StatCardProps) {
  return (
    <div className="rounded-lg border border-court-blue bg-court-blue/40 px-4 py-3">
      <div className="text-xs uppercase tracking-wide text-steel">{label}</div>
      <div className="font-mono text-2xl font-semibold text-chalk tabular-nums">{value}</div>
      {sublabel && <div className="mt-0.5 text-xs text-steel">{sublabel}</div>}
    </div>
  );
}
