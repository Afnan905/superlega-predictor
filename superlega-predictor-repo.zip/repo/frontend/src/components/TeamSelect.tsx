import type { Team } from "../lib/api";

interface TeamSelectProps {
  label: string;
  teams: Team[];
  value: string;
  onChange: (name: string) => void;
  excludeName?: string;
}

export default function TeamSelect({ label, teams, value, onChange, excludeName }: TeamSelectProps) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-medium uppercase tracking-wide text-steel">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-lg border border-court-blue bg-court-blue/40 px-3 py-2.5 text-chalk outline-none transition-colors focus:border-match-point"
      >
        <option value="" disabled>
          Select a team…
        </option>
        {teams
          .filter((t) => t.canonical_name !== excludeName)
          .map((t) => (
            <option key={t.id} value={t.canonical_name}>
              {t.canonical_name}
            </option>
          ))}
      </select>
    </label>
  );
}
