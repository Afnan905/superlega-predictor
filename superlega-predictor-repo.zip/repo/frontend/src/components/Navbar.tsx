import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Home", end: true },
  { to: "/predictor", label: "Match Predictor" },
  { to: "/predictions", label: "Predictions" },
  { to: "/teams", label: "Teams" },
  { to: "/model", label: "Model Performance" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-court-blue bg-court-navy/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <NavLink to="/" className="flex items-baseline gap-3">
          <span className="font-display text-2xl tracking-wide text-chalk">
            SUPERLEGA<span className="text-match-point">PREDICTOR</span>
          </span>
        </NavLink>
        <nav className="flex items-center gap-1">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) =>
                `rounded px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-court-blue text-match-point"
                    : "text-steel hover:bg-court-blue/60 hover:text-chalk"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}
