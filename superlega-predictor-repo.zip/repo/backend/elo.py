"""
elo.py

Dynamic Elo rating system for SuperLega teams.

Processes matches in STRICT CHRONOLOGICAL ORDER and stores, for every team
in every match, the rating BEFORE that match (what a real prediction would
have had access to) and the rating AFTER (updated using the actual result).
This is what lets historical predictions be reproduced exactly, and is the
foundation the leakage-prevention rule in features.py depends on.

USAGE:
    from elo import compute_elo_ratings
    ratings = compute_elo_ratings(matches)   # matches: list of dicts, see below
"""

from dataclasses import dataclass
from typing import Optional

INITIAL_RATING = 1500.0
K_FACTOR = 32.0
HOME_ADVANTAGE = 100.0  # Elo points added to home team's rating when computing expected result


@dataclass
class RatingRecord:
    match_id: int
    team_id: int
    is_home: bool
    rating_before: float
    rating_after: float
    expected_result: float
    actual_result: float
    rating_change: float


def expected_result(rating_a: float, rating_b: float) -> float:
    """Standard Elo expected-score formula."""
    return 1.0 / (1.0 + 10 ** ((rating_b - rating_a) / 400.0))


def compute_elo_ratings(matches: list) -> list:
    """
    matches: list of dicts, each with at least:
        match_id, date (ISO string, used only for ordering/assertion),
        home_team_id, away_team_id, home_sets, away_sets

    Matches MUST be sorted chronologically by the caller (this function
    asserts that and raises if not, rather than silently re-sorting —
    silently re-sorting could mask an upstream bug that fed data in the
    wrong order).

    Returns a flat list of RatingRecord, two per match (home + away).
    """
    for i in range(1, len(matches)):
        if matches[i]["date"] < matches[i - 1]["date"]:
            raise ValueError(
                f"matches must be pre-sorted chronologically; "
                f"match {matches[i]['match_id']} (date {matches[i]['date']}) "
                f"comes after match {matches[i-1]['match_id']} (date {matches[i-1]['date']}) "
                f"in the input list but has an earlier date"
            )

    current_rating: dict = {}
    records = []

    for m in matches:
        home_id, away_id = m["home_team_id"], m["away_team_id"]
        home_rating = current_rating.get(home_id, INITIAL_RATING)
        away_rating = current_rating.get(away_id, INITIAL_RATING)

        # Home advantage is applied only for computing the expected result,
        # not stored as part of the team's actual rating.
        exp_home = expected_result(home_rating + HOME_ADVANTAGE, away_rating)
        exp_away = 1.0 - exp_home

        home_won = m["home_sets"] > m["away_sets"]
        actual_home = 1.0 if home_won else 0.0
        actual_away = 1.0 - actual_home

        new_home_rating = home_rating + K_FACTOR * (actual_home - exp_home)
        new_away_rating = away_rating + K_FACTOR * (actual_away - exp_away)

        records.append(RatingRecord(
            match_id=m["match_id"], team_id=home_id, is_home=True,
            rating_before=home_rating, rating_after=new_home_rating,
            expected_result=exp_home, actual_result=actual_home,
            rating_change=new_home_rating - home_rating,
        ))
        records.append(RatingRecord(
            match_id=m["match_id"], team_id=away_id, is_home=False,
            rating_before=away_rating, rating_after=new_away_rating,
            expected_result=exp_away, actual_result=actual_away,
            rating_change=new_away_rating - away_rating,
        ))

        current_rating[home_id] = new_home_rating
        current_rating[away_id] = new_away_rating

    return records


def get_rating_before(records: list, team_id: int, match_id: int) -> Optional[float]:
    """Convenience lookup: this team's rating immediately before this match."""
    for r in records:
        if r.team_id == team_id and r.match_id == match_id:
            return r.rating_before
    return None
