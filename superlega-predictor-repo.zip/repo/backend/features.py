"""
features.py

Builds a feature vector for every match, using ONLY information that would
genuinely have been known immediately before that match was played.

CORE RULE (mandatory, see the project brief): when computing features for a
match on date D, only matches with an EARLIER date may be used. A match
played on the same date as another is never used as input to that other
match's features (same-day matches are treated as simultaneous — there's no
way to know which "came first" in the day, so neither may see the other).

This module does NOT trust the database's row order — it explicitly
re-sorts by date before doing anything, and every rolling/aggregate stat is
computed by filtering to strictly-earlier matches at the point of
computation, not by incrementally accumulating state in a single forward
pass (a forward pass is more efficient but is also exactly the kind of code
shape where an off-by-one mistake silently leaks the current match's own
result into its own features — filtering explicitly on every call is
slower but harder to get wrong).
"""

import sqlite3
from dataclasses import dataclass, field
from typing import Optional

from elo import compute_elo_ratings, RatingRecord

# The canonical list of feature columns used everywhere a model is trained
# or a prediction is made (train.py, predict.py) — defined once here so
# both stay in sync automatically rather than risking two independently
# maintained copies drifting apart.
FEATURE_COLUMNS = [
    "elo_diff",
    "home_last3_wins", "home_last5_wins", "away_last3_wins", "away_last5_wins",
    "home_last3_set_diff", "home_last5_set_diff", "away_last3_set_diff", "away_last5_set_diff",
    "home_season_win_pct", "away_season_win_pct",
    "home_home_win_pct", "away_away_win_pct",
    "h2h_home_wins", "h2h_away_wins", "h2h_set_diff",
]
LABEL_COLUMN = "home_won"


@dataclass
class MatchFeatures:
    match_id: int
    date: str
    home_team_id: int
    away_team_id: int
    season: Optional[str] = None

    home_elo: Optional[float] = None
    away_elo: Optional[float] = None
    elo_diff: Optional[float] = None

    home_last3_wins: Optional[int] = None
    home_last5_wins: Optional[int] = None
    away_last3_wins: Optional[int] = None
    away_last5_wins: Optional[int] = None
    home_last3_set_diff: Optional[int] = None
    home_last5_set_diff: Optional[int] = None
    away_last3_set_diff: Optional[int] = None
    away_last5_set_diff: Optional[int] = None

    home_season_win_pct: Optional[float] = None
    away_season_win_pct: Optional[float] = None
    home_home_win_pct: Optional[float] = None   # home team's win% specifically in home matches
    away_away_win_pct: Optional[float] = None   # away team's win% specifically in away matches

    h2h_home_wins: Optional[int] = None
    h2h_away_wins: Optional[int] = None
    h2h_set_diff: Optional[int] = None

    # Label (what we're trying to predict) — kept alongside features for
    # convenience in training, but NEVER used as an input feature itself.
    home_won: Optional[int] = None

    # Data-quality passthrough, so a low-confidence date doesn't silently
    # look identical to a confirmed one downstream.
    date_is_approximate: bool = False


def _team_prior_matches(all_matches: list, team_id: int, before_date: str) -> list:
    """All matches (home or away) for this team with date STRICTLY earlier
    than before_date. Same-day matches are excluded — see module docstring."""
    return [
        m for m in all_matches
        if m["date"] < before_date and (m["home_team_id"] == team_id or m["away_team_id"] == team_id)
    ]


def _team_result(m: dict, team_id: int) -> tuple:
    """Returns (won: bool, set_diff: int) for team_id in match m."""
    if m["home_team_id"] == team_id:
        won = m["home_sets"] > m["away_sets"]
        set_diff = m["home_sets"] - m["away_sets"]
    else:
        won = m["away_sets"] > m["home_sets"]
        set_diff = m["away_sets"] - m["home_sets"]
    return won, set_diff


def _recent_form(all_matches: list, team_id: int, before_date: str, n: int) -> tuple:
    """Wins and set-differential over the team's last n matches strictly
    before before_date. Returns (None, None) if fewer than n prior matches
    exist — we do NOT pad with zeros, since that would misrepresent a
    team's form as worse than unknown."""
    prior = sorted(_team_prior_matches(all_matches, team_id, before_date), key=lambda m: m["date"])
    if len(prior) < n:
        return None, None
    last_n = prior[-n:]
    wins = sum(1 for m in last_n if _team_result(m, team_id)[0])
    set_diff = sum(_team_result(m, team_id)[1] for m in last_n)
    return wins, set_diff


def _season_win_pct(all_matches: list, team_id: int, before_date: str, home_only: Optional[bool] = None) -> Optional[float]:
    prior = _team_prior_matches(all_matches, team_id, before_date)
    if home_only is True:
        prior = [m for m in prior if m["home_team_id"] == team_id]
    elif home_only is False:
        prior = [m for m in prior if m["away_team_id"] == team_id]
    if not prior:
        return None
    wins = sum(1 for m in prior if _team_result(m, team_id)[0])
    return wins / len(prior)


def _head_to_head(all_matches: list, home_id: int, away_id: int, before_date: str) -> tuple:
    prior = [
        m for m in all_matches
        if m["date"] < before_date
        and {m["home_team_id"], m["away_team_id"]} == {home_id, away_id}
    ]
    home_wins = sum(1 for m in prior if _team_result(m, home_id)[0])
    away_wins = sum(1 for m in prior if _team_result(m, away_id)[0])
    set_diff = sum(_team_result(m, home_id)[1] for m in prior)
    if not prior:
        return None, None, None
    return home_wins, away_wins, set_diff


def build_features(all_matches: list) -> list:
    """
    all_matches: list of dicts with match_id, date, home_team_id,
    away_team_id, home_sets, away_sets, date_is_approximate (optional).

    Returns a list of MatchFeatures, one per match, sorted chronologically.
    """
    sorted_matches = sorted(all_matches, key=lambda m: (m["date"], m["match_id"]))

    elo_records = compute_elo_ratings(sorted_matches)
    elo_before_lookup = {(r.match_id, r.team_id): r.rating_before for r in elo_records}

    results = []
    for m in sorted_matches:
        mid, date = m["match_id"], m["date"]
        home_id, away_id = m["home_team_id"], m["away_team_id"]

        home_elo = elo_before_lookup.get((mid, home_id))
        away_elo = elo_before_lookup.get((mid, away_id))

        h_last3_w, h_last3_sd = _recent_form(sorted_matches, home_id, date, 3)
        h_last5_w, h_last5_sd = _recent_form(sorted_matches, home_id, date, 5)
        a_last3_w, a_last3_sd = _recent_form(sorted_matches, away_id, date, 3)
        a_last5_w, a_last5_sd = _recent_form(sorted_matches, away_id, date, 5)

        home_season_pct = _season_win_pct(sorted_matches, home_id, date)
        away_season_pct = _season_win_pct(sorted_matches, away_id, date)
        home_home_pct = _season_win_pct(sorted_matches, home_id, date, home_only=True)
        away_away_pct = _season_win_pct(sorted_matches, away_id, date, home_only=False)

        h2h_home_w, h2h_away_w, h2h_sd = _head_to_head(sorted_matches, home_id, away_id, date)

        results.append(MatchFeatures(
            match_id=mid, date=date, home_team_id=home_id, away_team_id=away_id,
            season=m.get("season"),
            home_elo=home_elo, away_elo=away_elo,
            elo_diff=(home_elo - away_elo) if home_elo is not None and away_elo is not None else None,
            home_last3_wins=h_last3_w, home_last5_wins=h_last5_w,
            away_last3_wins=a_last3_w, away_last5_wins=a_last5_w,
            home_last3_set_diff=h_last3_sd, home_last5_set_diff=h_last5_sd,
            away_last3_set_diff=a_last3_sd, away_last5_set_diff=a_last5_sd,
            home_season_win_pct=home_season_pct, away_season_win_pct=away_season_pct,
            home_home_win_pct=home_home_pct, away_away_win_pct=away_away_pct,
            h2h_home_wins=h2h_home_w, h2h_away_wins=h2h_away_w, h2h_set_diff=h2h_sd,
            home_won=1 if m["home_sets"] > m["away_sets"] else 0,
            date_is_approximate=bool(m.get("date_is_approximate", False)),
        ))

    return results


def load_matches_from_db(db_path: str) -> list:
    """
    Loads COMPLETED matches only, for training/feature computation.
    Upcoming matches (is_completed=0, NULL scores) must be excluded here —
    they have no result to learn from, and would crash Elo/feature
    computation if included (comparing NoneType scores).
    """
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("""
        SELECT m.id AS match_id, m.date, m.date_is_approximate, m.home_team_id, m.away_team_id,
               m.home_sets, m.away_sets, s.name AS season
        FROM matches m
        JOIN seasons s ON m.season_id = s.id
        WHERE m.date IS NOT NULL AND m.is_completed = 1
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


if __name__ == "__main__":
    matches = load_matches_from_db("../superlega.db")
    features = build_features(matches)
    print(f"Built features for {len(features)} matches.")
    for f in features[:3]:
        print(f)
