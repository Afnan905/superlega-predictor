"""
legavolley_scraper.py

Scrapes real historical SuperLega match data from legavolley.it by walking the
site's chained matchday news articles ("...RISULTATI CLASSIFICA" and
"...TABELLINI" posts), which are linked together via "Articolo precedente" /
"Prossimo articolo" navigation.

WHY THIS APPROACH:
  legavolley.it's generic /risultati/ page is a JS-driven app (loads data via
  AJAX with query params) and returns nothing useful to a plain HTTP GET.
  Its individual matchday news articles, however, are static server-rendered
  HTML containing real final scores, set-by-set results, and (on TABELLINI
  articles) per-player point totals. These articles form a linked list you
  can walk sequentially, article by article, without guessing URLs.

WHAT THIS DOES NOT DO:
  - It does NOT invent, estimate, or fill in any missing data. If a field
    can't be parsed from the page, it is left blank/null and logged, never
    guessed.
  - It does NOT pull granular DataVolley-style stats (attack %, block points,
    serve efficiency, reception %) — those were not confirmed to exist in
    this article format. Only: date, teams, set scores, winner, and
    (for TABELLINI articles) per-player point totals.
  - It respects robots.txt and rate-limits requests (default 2s between
    fetches) to avoid hammering the server.

REQUIREMENTS:
  pip install requests beautifulsoup4

USAGE (Google Colab or any notebook):
  1. Paste this entire file into a cell.
  2. Edit the CONFIG block near the top (START_URL, DIRECTION, SEASON_LABEL,
     etc.) for what you want to scrape.
  3. Run the cell. No command-line arguments needed — everything is
     controlled by the CONFIG block, so this works directly when pasted
     into a notebook (unlike argparse-based scripts, which error out when
     run inside Colab/Jupyter because the kernel injects its own args).

USAGE (terminal / local machine):
  Just edit the CONFIG block the same way, save the file, and run:
      python legavolley_scraper.py

NOTE ON FINDING A STARTING URL FOR OTHER SEASONS (2022-23, 2023-24, 2024-25):
  This script cannot discover the season's first article on its own — you
  need to find at least one real matchday article URL for that season first
  (e.g. via legavolley.it's own site search, Google site-search
  "site:legavolley.it 2022 giornata risultati", or the /category/superlega/
  archive pages) and set it as START_URL in the CONFIG block. Once you have
  ONE article URL for a season, this script can walk the entire chain from
  there — just re-run with a different START_URL/SEASON_LABEL/OUT_CSV for
  each season.
"""

import csv
import logging
import re
import sys
import time
from dataclasses import dataclass, field
from typing import Optional
from urllib import robotparser
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

# =============================================================================
# CONFIG — edit these values directly, then run the whole cell.
# (No command-line arguments needed — this is Colab/Jupyter-friendly.)
# =============================================================================

START_URL = (
    "https://www.legavolley.it/2026/1a-giornata-and-19-10-2025-regular-season-"
    "superlega-credem-banca-stagione-2025-tabellini-2/"
)
DIRECTION = "forward"       # "forward" follows 'Prossimo articolo', "backward" follows 'Articolo precedente'
SEASON_LABEL = "2025-26"    # stamped onto every output row
MAX_PAGES = 60              # safety cap on how many articles to fetch in one run
SLEEP_SECONDS = 2.0         # delay between requests — do not set this too low
OUT_CSV = "matches_2025_26.csv"
PLAYERS_OUT_CSV = "players_2025_26.csv"
LOG_OUT_CSV = "scrape_log.csv"

# Set this to True to just print the site's actual robots.txt content and
# what it means for START_URL, instead of running the full crawl. Useful
# for checking exactly what's disallowed (and for whom) before scraping.
DIAGNOSTIC_ONLY = False

# ---- Discovery mode -----------------------------------------------------
# The TABELLINI/RISULTATI CLASSIFICA article chain only covers SOME
# matchdays (confirmed: it jumps from Giornata 1 straight to Giornata 11).
# Most matchdays are only covered by ordinary single-match news articles,
# which are NOT linked in a walkable chain the way TABELLINI posts are.
# Discovery mode instead paginates through legavolley.it's category archive
# (https://www.legavolley.it/category/superlega/page/N/), which lists every
# SuperLega article in reverse-chronological order back to ~2013, and
# collects real article URLs from each listing page to feed into the same
# parsing logic used elsewhere in this script.
#
# Set DISCOVERY_MODE = True to use this instead of the chain-walk crawl.
DISCOVERY_MODE = True
SEASON_LABEL = "2022-23"    # NOTE: also update this whenever targeting a different season
CATEGORY_START_PAGE = 650   # estimated ~May 2023 (playoffs end, rough estimate)
CATEGORY_END_PAGE = 698     # picks up right before the previous batch (699-764, Nov 2022-Feb 2023); covers season end (Mar 12 2023) + playoffs (~49 pages)
DISCOVERY_OUT_CSV = "matches_discovered.csv"
DISCOVERY_PLAYERS_OUT_CSV = "players_discovered.csv"
DISCOVERY_LOG_OUT_CSV = "discovery_log.csv"

# When True, if an article's title doesn't contain an explicit DD/MM/YYYY
# (true for ordinary recap articles, unlike TABELLINI posts), fall back to
# using the article's PUBLISH date instead of leaving date blank. This is
# an approximation, not a fact — for near-real-time match recaps the
# publish date is usually the match date or the day after, but this is NOT
# guaranteed. Every row using this fallback is explicitly flagged
# DATE_IS_PUBLISH_DATE_APPROXIMATION so nothing downstream mistakes it for
# a confirmed date. Off by default — turn on deliberately.
ALLOW_PUBLISH_DATE_FALLBACK = True

# =============================================================================

USER_AGENT = (
    "SuperLegaPredictorResearchBot/1.0 "
    "(educational/analytical project; respects robots.txt and rate limits; "
    "contact: set-your-contact-email-here)"
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("legavolley_scraper")


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class MatchRecord:
    source_url: str
    article_type: str          # "TABELLINI" or "RISULTATI_CLASSIFICA" or "UNKNOWN"
    giornata_label: Optional[str] = None
    date: Optional[str] = None            # ISO YYYY-MM-DD if parseable, else raw text
    home_team: Optional[str] = None
    away_team: Optional[str] = None
    home_sets: Optional[int] = None
    away_sets: Optional[int] = None
    winner: Optional[str] = None
    set_scores: Optional[str] = None      # "25-15,25-16,23-25,25-23"
    validation_flags: list = field(default_factory=list)


@dataclass
class PlayerLine:
    source_url: str
    team: str
    player_name: str
    points: Optional[int]


# ---------------------------------------------------------------------------
# robots.txt / fetching
# ---------------------------------------------------------------------------

_robots_cache = {}


def _robots_allowed(url: str) -> bool:
    parsed = urlparse(url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    if base not in _robots_cache:
        robots_url = base + "/robots.txt"
        rp = robotparser.RobotFileParser()
        try:
            # Fetch via requests (reliable, consistent with the rest of this
            # script) rather than robotparser's own .read(), which uses
            # urllib under the hood and was observed to fail silently in
            # some notebook environments (e.g. Colab), causing every URL to
            # be defensively treated as disallowed even when robots.txt
            # actually permits it.
            resp = requests.get(robots_url, headers={"User-Agent": USER_AGENT}, timeout=20)
            resp.raise_for_status()
            rp.parse(resp.text.splitlines())
        except requests.RequestException as e:
            log.warning("Could not read robots.txt for %s (%s) — refusing to proceed", base, e)
            _robots_cache[base] = None
            return False
        _robots_cache[base] = rp
    rp = _robots_cache[base]
    if rp is None:
        return False
    return rp.can_fetch(USER_AGENT, url)


FETCH_TIMEOUT_SECONDS = 30
FETCH_MAX_RETRIES = 3


def fetch(url: str, sleep_seconds: float) -> Optional[str]:
    if not _robots_allowed(url):
        log.error("robots.txt disallows fetching %s — skipping.", url)
        return None

    last_error = None
    for attempt in range(1, FETCH_MAX_RETRIES + 1):
        try:
            resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=FETCH_TIMEOUT_SECONDS)
            resp.raise_for_status()
            time.sleep(sleep_seconds)
            return resp.text
        except requests.RequestException as e:
            last_error = e
            if attempt < FETCH_MAX_RETRIES:
                backoff = sleep_seconds * (2 ** attempt)  # 2x, 4x, 8x the base delay
                log.warning("Fetch attempt %d/%d failed for %s (%s) — retrying in %.1fs",
                            attempt, FETCH_MAX_RETRIES, url, e, backoff)
                time.sleep(backoff)
            else:
                log.error("Fetch failed for %s after %d attempts: %s", url, FETCH_MAX_RETRIES, e)

    return None


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

MONTHS_IT = {
    "gennaio": 1, "febbraio": 2, "marzo": 3, "aprile": 4, "maggio": 5, "giugno": 6,
    "luglio": 7, "agosto": 8, "settembre": 9, "ottobre": 10, "novembre": 11, "dicembre": 12,
}

# e.g. "19/10/2025" inside a title
DATE_SLASH_RE = re.compile(r"(\d{2})/(\d{2})/(\d{4})")

# e.g. "Team A – Team B 3-1 (25-15, 25-16, 23-25, 25-23)"
# Team names: words made of letters/apostrophes/periods only (no digits, no
# newlines), capped at 6 words, so this can't run on into a following
# player's "Name NN" point tally the way an unbounded \s-inclusive class would.
_TEAM_WORD = r"[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'\.]*"
_TEAM_NAME = rf"{_TEAM_WORD}(?:[ \t]{_TEAM_WORD}){{0,6}}"
MATCH_HEADER_RE = re.compile(
    rf"({_TEAM_NAME})[ \t]*[–-][ \t]*({_TEAM_NAME})[ \t]+"
    r"(\d)-(\d)[ \t]*\(([\d\-,\s]+)\)"
)

# Text that marks the end of the real article body on legavolley.it. Anything
# from here onward is sidebar/related-content widgets (e.g. a "Latest videos"
# box that appears identically on every page of the site and was confirmed,
# via manual inspection, to inject an unrelated match score into every page's
# text — the root cause of ~58 duplicate phantom-match rows in an earlier run).
BODY_END_MARKERS = ["Articolo precedente", "Prossimo articolo", "Articoli correlati", "ALTRE NEWS"]

# Known noise-prefix tokens seen bleeding into captured team names from
# non-TABELLINI recap articles (e.g. "Il tabellino Sonepar Padova...",
# "Facebook Twitter WhatsApp Linkedin Print Cisterna Volley..."). We do NOT
# silently strip-and-trust these — we flag the record so a human/downstream
# validator can review it, per the "never silently fix bad data" rule.
SUSPICIOUS_TEAM_NAME_TOKENS = [
    "facebook", "twitter", "whatsapp", "linkedin", "print", "tabellino",
    "regular season", "superlega credem banca", "andata", "ritorno",
    "giocata ieri", "giocata oggi", "giocate ieri", "giocate oggi",
    "giocata sabato", "giocata domenica", "giocata venerdi", "giocata venerdì",
    "gara 1", "gara 2", "gara 3", "gara 4", "gara 5",
    "gli spettatori", "gli tifosi", "coppa italia", "finale", "preliminari",
    "banca", "turno",
    "gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno",
    "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre",
]

# A leading token like "Pozzato. Rana Verona" (a referee surname bleeding in
# from the previous match's "ARBITRI:" line) looks like: one capitalized
# word, a period, then another capitalized word. Legitimate team names never
# contain a mid-name period followed by a new capitalized word this way.
_LEAKED_PREFIX_RE = re.compile(r"^[A-ZÀ-Ý][a-zà-ÿ]+\.\s+[A-ZÀ-Ý]")

# Known real SuperLega 2025-26 teams, built directly from the confirmed-clean
# TABELLINI rows (Giornata 1 + Giornata 11), NOT from the site's live
# navigation menu — that menu reflects the *current* (2026-27) roster after
# promotion/relegation, and would incorrectly exclude e.g. Yuasa Battery
# Grottazzolina, which played in SuperLega in 2025-26 but was relegated to
# A2 for 2026-27. Team rosters change every season, so this list is
# season-specific and will need to be rebuilt (from that season's own
# confirmed-clean data) when scraping other seasons.
#
# Includes known sponsor-name variants seen across articles for the same
# club (e.g. "Vero Volley Monza" vs "Autopancotti Vero Volley Monza").
KNOWN_SUPERLEGA_TEAMS_2025_26 = [
    "Cucine Lube Civitanova",
    "Yuasa Battery Grottazzolina",
    "Rana Verona",
    "WithU Verona",  # 2022-23 season sponsor variant
    "Gas Sales Bluenergy Piacenza",
    "Gas Sales Bluenergy Volley Piacenza",  # variant seen in Nov 2025-Jan 2026 coverage
    "Gas Sales Daiko Piacenza",  # 2023-24 season sponsor variant
    "Allianz Milano",
    "Valsa Group Modena",
    "Cisterna Volley",
    "Top Volley Cisterna",  # 2022-23 season sponsor variant
    "Itas Trentino",
    "Trentino Itas",  # word-order variant, seen in European-competition coverage
    "Sonepar Padova",
    "Pallavolo Padova",  # 2023-24 season name for Sonepar Padova
    "MA Acqua S.Bernardo Cuneo",
    "Vero Volley Monza",
    "Autopancotti Vero Volley Monza",
    "Sir Susa Scai Perugia",
    "Sir Safety Susa Perugia",  # 2022-23 season sponsor variant
    "Sir Safety Conad Perugia",  # 2022-23 season mid-season sponsor variant
    "Emma Villas Aubay Siena",  # 2022-23 season team, relegated after that season
    "Emma Villas Siena",  # shortened form seen in some articles
    "Sir Sicoma Monini Perugia",  # sponsor name seen in February 2026 coverage
    "Sir Susa Vim Perugia",  # 2024-25 season sponsor variant
    "Mint Vero Volley Monza",  # 2024-25 season sponsor variant
    "Gioiella Prisma Taranto",  # 2024-25 season team, not in 2025-26 league (relegated/replaced by Cuneo)
    "Farmitalia Catania",  # 2023-24 season team, first-ever SuperLega appearance
]


def team_is_recognized(name: Optional[str]) -> bool:
    """
    EXACT (case-insensitive) match against the known-team whitelist only —
    not loose substring containment. Loose containment was tried first and
    found to be a real problem: "Itas Trentino" is a substring of
    "Perugia Itas Trentino" (a genuine prefix-bleed artifact, e.g. from
    "...si arrende a Perugia. Itas Trentino ..."), so containment matching
    silently accepted the contaminated name as if it were a legitimate
    sponsor variant. Every REAL sponsor-name variant we've encountered
    (e.g. "Autopancotti Vero Volley Monza", "Sir Sicoma Monini Perugia")
    has been added to KNOWN_SUPERLEGA_TEAMS_2025_26 explicitly, so exact
    matching doesn't lose legitimate data — it just stops silently trusting
    unlisted variants, which get NOT_RECOGNIZED_TEAM instead (safer:
    logged for review rather than silently accepted).
    """
    if not name:
        return False
    low = name.lower().strip()
    return any(low == known.lower() for known in KNOWN_SUPERLEGA_TEAMS_2025_26)


def extract_article_body(soup: BeautifulSoup, title_tag) -> str:
    """
    Scopes text down to just the real article body: everything in the
    document AFTER the title tag, up to the first sidebar/related-content
    marker. This walks the actual DOM tree (title_tag.find_all_next())
    rather than searching for the title's text within a flattened string —
    string-matching turned out to be fragile (a real run produced every
    single row dated "today", traced to the title-text lookup silently
    failing to anchor correctly and falling back to scanning the ENTIRE
    page, including a header "current page load time" widget that always
    appears before any real content). DOM traversal from the tag itself
    can't be fooled by duplicate/truncated title text appearing elsewhere
    (e.g. in a breadcrumb) the way string search could.
    """
    if title_tag is None:
        return soup.get_text(" ", strip=True)
    parts = []
    for node in title_tag.find_all_next(string=True):
        # find_all_next() on a tag includes that tag's OWN child text nodes
        # first (they're "next" in parse-tree order relative to the tag's
        # opening) — skip those, we only want text that comes AFTER the
        # title, not the title's own text repeated into the body.
        if title_tag in node.parents:
            continue
        text = node.strip()
        if not text:
            continue
        if any(marker in text for marker in BODY_END_MARKERS):
            break
        parts.append(text)
    return " ".join(parts)


def team_name_is_suspicious(name: Optional[str]) -> bool:
    if not name:
        return True
    low = name.lower()
    if any(tok in low for tok in SUSPICIOUS_TEAM_NAME_TOKENS):
        return True
    if _LEAKED_PREFIX_RE.match(name):
        return True
    if len(name.split()) > 5:
        return True
    return False

# e.g. "Nikolov 30" inside a team roster block
PLAYER_POINTS_RE = re.compile(r"([A-ZÀ-Ý][A-Za-zÀ-ÿ'’\.\- ]{1,40}?)\s(\d{1,2})(?=[,\.]|\s[A-ZÀ-Ý]|\s*$)")


def detect_article_type(title: str) -> str:
    t = title.upper()
    if "TABELLINI" in t:
        return "TABELLINI"
    if "RISULTATI CLASSIFICA" in t or "RISULTATI" in t and "CLASSIFICA" in t:
        return "RISULTATI_CLASSIFICA"
    return "UNKNOWN"


def parse_date_from_title(title: str) -> Optional[str]:
    m = DATE_SLASH_RE.search(title)
    if m:
        dd, mm, yyyy = m.groups()
        return f"{yyyy}-{mm}-{dd}"
    return None


def parse_giornata_label(title: str) -> Optional[str]:
    m = re.search(r"(\d+ª\s*Giornata[^\(\-–]*)", title, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None


def parse_matches_from_text(full_text: str, source_url: str, article_type: str,
                             giornata_label: Optional[str], date: Optional[str]) -> list:
    """
    Finds match header patterns like:
      "Cucine Lube Civitanova – Yuasa Battery Grottazzolina 3-1 (25-15, 25-16, 23-25, 25-23)"
    Works for both TABELLINI (full recaps) and RISULTATI CLASSIFICA (semicolon-separated
    list) article bodies, since both contain this same header pattern.
    """
    matches = []
    for m in MATCH_HEADER_RE.finditer(full_text):
        home_raw, away_raw, home_sets_s, away_sets_s, set_scores_raw = m.groups()
        home_team = home_raw.strip(" -–.").lstrip(". ")
        away_team = away_raw.strip(" -–.").lstrip(". ")
        home_sets = int(home_sets_s)
        away_sets = int(away_sets_s)
        set_scores = ",".join(s.strip() for s in set_scores_raw.split(","))

        record = MatchRecord(
            source_url=source_url,
            article_type=article_type,
            giornata_label=giornata_label,
            date=date,
            home_team=home_team,
            away_team=away_team,
            home_sets=home_sets,
            away_sets=away_sets,
            set_scores=set_scores,
        )

        # --- validation (log, never silently fix) ---
        if home_sets == away_sets:
            record.validation_flags.append("IMPOSSIBLE_RESULT: sets tied, no volleyball match ends in a draw")
        if max(home_sets, away_sets) != 3:
            record.validation_flags.append(f"UNUSUAL_RESULT: winner has {max(home_sets, away_sets)} sets, expected 3")
        if not home_team or not away_team:
            record.validation_flags.append("MISSING_TEAM_NAME")
        if team_name_is_suspicious(home_team) or team_name_is_suspicious(away_team):
            record.validation_flags.append(
                "SUSPICIOUS_TEAM_NAME: contains a known noise token (e.g. social-share text, "
                "'tabellino', boilerplate phrase) — likely a mis-parsed boundary, review before use"
            )
        elif home_team and away_team and not (team_is_recognized(home_team) and team_is_recognized(away_team)):
            record.validation_flags.append(
                "NOT_RECOGNIZED_TEAM: one or both teams aren't in the known SuperLega 2025-26 "
                "roster — this may be a different competition (e.g. a friendly, Junior League, "
                "another division) that leaked in via the article chain, not a real SuperLega match"
            )
        if date is None:
            record.validation_flags.append("MISSING_DATE: could not parse date from article title")

        record.winner = home_team if home_sets > away_sets else away_team

        matches.append(record)
    return matches


def parse_player_points(full_text: str, source_url: str, matches: list) -> list:
    """
    Best-effort extraction of "PlayerName ##" point tallies from TABELLINI article
    bodies. This is approximate (regex over free text, not a structured table) and
    should be spot-checked. Rows with ambiguous parses are still emitted but can be
    filtered downstream using the confidence the pipeline assigns.
    """
    players = []
    if not matches:
        return players
    # Split the raw text on team names found in matches to approximate which
    # block of text belongs to which team. This is a heuristic, not exact.
    for rec in matches:
        for team_name in (rec.home_team, rec.away_team):
            if not team_name:
                continue
            # crude: look for "TeamName: Player NN, Player NN, ..." pattern
            block_re = re.escape(team_name) + r":\s*(.+?)(?:N\.E\.|All\.|ARBITRI|$)"
            block_match = re.search(block_re, full_text)
            if not block_match:
                continue
            block_text = block_match.group(1)
            for pm in PLAYER_POINTS_RE.finditer(block_text):
                name, pts = pm.groups()
                name = name.strip(" ,.")
                if len(name) < 2:
                    continue
                players.append(PlayerLine(
                    source_url=source_url,
                    team=team_name,
                    player_name=name,
                    points=int(pts),
                ))
    return players


def parse_publish_date(page_text: str) -> Optional[str]:
    """
    Looks for the "Da [Author] - DD Mese YYYY" publish-date line seen on
    legavolley.it article pages (e.g. "25 Febbraio 2026"). Returns ISO
    YYYY-MM-DD, or None if no such pattern is found. This is the article's
    PUBLISH date, not necessarily the match date — callers must treat it as
    an approximation (see ALLOW_PUBLISH_DATE_FALLBACK).
    """
    months_pattern = "|".join(MONTHS_IT.keys())
    m = re.search(rf"(\d{{1,2}})\s+({months_pattern})\s+(\d{{4}})", page_text, re.IGNORECASE)
    if not m:
        return None
    day, month_name, year = m.groups()
    month = MONTHS_IT[month_name.lower()]
    return f"{year}-{month:02d}-{int(day):02d}"


# Article URLs on legavolley.it consistently follow /YYYY/slug/ (confirmed
# across every real article seen so far), while navigation/category/team
# links use different shapes (/team/1234, /category/..., /risultati/, etc).
# This is the heuristic used to pick real article links out of a category
# listing page.
_ARTICLE_URL_RE = re.compile(r"https://www\.legavolley\.it/20\d\d/[a-z0-9\-]+/?(?=[\"'\s>]|$)")


def discover_article_urls(category_url_template: str, start_page: int, end_page: int,
                           sleep_seconds: float) -> list:
    """
    Walks legavolley.it's category archive pages and collects candidate
    article URLs. Does NOT try to guess which ones are match reports vs.
    other news (transfers, previews, etc.) — that filtering happens
    naturally downstream, since parse_matches_from_text() simply finds zero
    matches on non-report articles and they're logged as NO_MATCHES_PARSED
    rather than silently skipped.
    """
    urls = set()
    for page_num in range(start_page, end_page + 1):
        page_url = category_url_template.format(page=page_num)
        log.info("Discovering articles on page %d: %s", page_num, page_url)
        html = fetch(page_url, sleep_seconds)
        if html is None:
            log.warning("Could not fetch category page %d — stopping discovery.", page_num)
            break
        found = set(_ARTICLE_URL_RE.findall(html))
        log.info("  found %d candidate article URLs on this page", len(found))
        urls.update(found)
    return sorted(urls)
    """
    direction: "forward" looks for the "Prossimo articolo" link,
               "backward" looks for the "Articolo precedente" link.
    legavolley.it renders these as plain text followed by an <a> tag in the
    page body (confirmed by manual inspection). We search for the anchor
    whose surrounding text contains the marker phrase.
    """
    marker = "Prossimo articolo" if direction == "forward" else "Articolo precedente"
    # Look for any tag containing the marker text, then find the nearest following <a href>
    for el in soup.find_all(string=re.compile(marker, re.IGNORECASE)):
        parent = el.parent
        # search siblings/parent for an <a href>
        a = parent.find("a", href=True) if parent else None
        if a:
            return a["href"]
        # fallback: look at the parent's parent
        if parent and parent.parent:
            a = parent.parent.find("a", href=True)
            if a:
                return a["href"]
    return None


# ---------------------------------------------------------------------------
# Main crawl loop
# ---------------------------------------------------------------------------

def find_adjacent_article_url(soup: BeautifulSoup, direction: str) -> Optional[str]:
    """
    direction: "forward" looks for the "Prossimo articolo" link,
               "backward" looks for the "Articolo precedente" link.

    Uses find_next(), which walks forward through the document in reading
    order from the marker text to the nearest following <a href>. This
    matters: an earlier version used parent.find()/parent.parent.find(),
    which searches a container's children rather than "the next thing after
    this text" — when both "Articolo precedente" and "Prossimo articolo"
    markers (and their links) sit in the same nav container, that earlier
    approach always returned whichever <a> happened to appear FIRST in the
    container, regardless of which direction was actually requested. This
    is the likely real cause of the chain jumping straight from Giornata 1
    to Giornata 11 instead of walking sequentially through 2-10.
    """
    marker = "Prossimo articolo" if direction == "forward" else "Articolo precedente"
    for el in soup.find_all(string=re.compile(marker, re.IGNORECASE)):
        a = el.find_next("a", href=True)
        if a:
            return a["href"]
    return None


def crawl(start_url: str, direction: str, season_label: str, max_pages: int,
          sleep_seconds: float, out_csv: str, players_csv: Optional[str],
          log_csv: str):

    visited = set()
    url = start_url
    all_matches = []
    all_players = []
    error_log_rows = []

    pages_done = 0
    while url and pages_done < max_pages:
        if url in visited:
            log.info("Already visited %s — stopping (loop detected).", url)
            break
        visited.add(url)

        log.info("Fetching (%d/%d): %s", pages_done + 1, max_pages, url)
        html = fetch(url, sleep_seconds)
        if html is None:
            error_log_rows.append({"url": url, "issue": "FETCH_FAILED"})
            break

        soup = BeautifulSoup(html, "html.parser")
        title_tag = soup.find("h1") or soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""

        article_type = detect_article_type(title)
        date = parse_date_from_title(title)
        giornata_label = parse_giornata_label(title)

        # Grab the main article text, scoped to just the real body (title
        # tag -> first sidebar/nav marker) via DOM traversal — see
        # extract_article_body's docstring for why this must be DOM-based
        # rather than string-matching-based.
        full_text = soup.get_text(" ", strip=True)
        article_text = extract_article_body(soup, title_tag)

        date_is_approximate = False
        if date is None and ALLOW_PUBLISH_DATE_FALLBACK:
            # IMPORTANT: search only the scoped article body, not full_text.
            # full_text also contains a "current page load time" header
            # widget (e.g. "lunedì 10 agosto 2026 22:19") AND unrelated
            # sidebar article dates further down the page — both of which
            # would incorrectly match before the real byline date if
            # searched globally, since re.search returns the first match.
            date = parse_publish_date(article_text)
            if date is not None:
                date_is_approximate = True

        matches = parse_matches_from_text(article_text, url, article_type, giornata_label, date)
        if date_is_approximate:
            for rec in matches:
                rec.validation_flags.append(
                    "DATE_IS_PUBLISH_DATE_APPROXIMATION: no explicit date in title; used article "
                    "publish date as an approximation, which may be off by a day or more"
                )
        if not matches:
            error_log_rows.append({"url": url, "issue": "NO_MATCHES_PARSED — page format may differ, inspect manually"})
        else:
            all_matches.extend(matches)
            for rec in matches:
                for flag in rec.validation_flags:
                    error_log_rows.append({"url": url, "issue": flag})

        if article_type == "TABELLINI" and players_csv:
            players = parse_player_points(article_text, url, matches)
            all_players.extend(players)

        next_url = find_adjacent_article_url(soup, direction)
        if next_url and next_url.startswith("/"):
            parsed = urlparse(url)
            next_url = f"{parsed.scheme}://{parsed.netloc}{next_url}"

        if not next_url:
            log.info("No further '%s' link found — reached the end of the chain.", direction)
            break

        url = next_url
        pages_done += 1

    # --- write outputs ---
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "season", "giornata_label", "date", "home_team", "away_team",
            "home_sets", "away_sets", "winner", "set_scores",
            "source_url", "article_type", "validation_flags",
        ])
        for rec in all_matches:
            writer.writerow([
                season_label, rec.giornata_label, rec.date, rec.home_team, rec.away_team,
                rec.home_sets, rec.away_sets, rec.winner, rec.set_scores,
                rec.source_url, rec.article_type, "; ".join(rec.validation_flags),
            ])
    log.info("Wrote %d match rows to %s", len(all_matches), out_csv)

    if players_csv:
        with open(players_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["season", "team", "player_name", "points", "source_url"])
            for p in all_players:
                writer.writerow([season_label, p.team, p.player_name, p.points, p.source_url])
        log.info("Wrote %d player-point rows to %s", len(all_players), players_csv)

    with open(log_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "issue"])
        for row in error_log_rows:
            writer.writerow([row["url"], row["issue"]])
    log.info("Wrote %d validation/error log rows to %s", len(error_log_rows), log_csv)

    log.info("Done. Pages fetched: %d. Matches parsed: %d. Errors/flags logged: %d.",
              pages_done, len(all_matches), len(error_log_rows))


def print_robots_diagnostic(url: str):
    """Fetches and prints the target site's actual robots.txt, plus the
    specific allow/disallow ruling for our USER_AGENT and the given url —
    so decisions about what to scrape are based on the real published rules,
    not guesswork."""
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    print(f"Fetching {robots_url} ...\n")
    try:
        resp = requests.get(robots_url, headers={"User-Agent": USER_AGENT}, timeout=20)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"Could not fetch robots.txt: {e}")
        return
    print("=" * 70)
    print(resp.text)
    print("=" * 70)

    rp = robotparser.RobotFileParser()
    rp.parse(resp.text.splitlines())
    allowed_ours = rp.can_fetch(USER_AGENT, url)
    allowed_generic = rp.can_fetch("Mozilla/5.0", url)
    allowed_star = rp.can_fetch("*", url)
    print(f"\nRuling for our USER_AGENT ('{USER_AGENT[:40]}...'):")
    print(f"  -> {'ALLOWED' if allowed_ours else 'DISALLOWED'} for {url}")
    print(f"Ruling for a generic browser-style UA ('Mozilla/5.0'):")
    print(f"  -> {'ALLOWED' if allowed_generic else 'DISALLOWED'} for {url}")
    print(f"Ruling for a bare '*' UA:")
    print(f"  -> {'ALLOWED' if allowed_star else 'DISALLOWED'} for {url}")


def crawl_discovered_urls(urls: list, season_label: str, sleep_seconds: float,
                           out_csv: str, players_csv: Optional[str], log_csv: str):
    """
    Same per-page parsing logic as crawl(), but driven by a pre-collected
    list of URLs (from discover_article_urls) instead of following a
    next-article chain. Articles with zero recognizable matches are logged
    and skipped, not treated as errors — most category-archive pages are
    NOT match reports (transfers, previews, club news, etc).
    """
    all_matches = []
    all_players = []
    error_log_rows = []

    for i, url in enumerate(urls):
        log.info("Processing (%d/%d): %s", i + 1, len(urls), url)
        html = fetch(url, sleep_seconds)
        if html is None:
            error_log_rows.append({"url": url, "issue": "FETCH_FAILED"})
            continue

        soup = BeautifulSoup(html, "html.parser")
        title_tag = soup.find("h1") or soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""

        article_type = detect_article_type(title)
        date = parse_date_from_title(title)
        date_is_approximate = False
        full_text = soup.get_text(" ", strip=True)
        giornata_label = parse_giornata_label(title)
        article_text = extract_article_body(soup, title_tag)

        # IMPORTANT: search only the scoped article body, not full_text —
        # see the matching comment in crawl() for why (a "current page load
        # time" header widget and unrelated sidebar dates elsewhere on the
        # page would otherwise be matched first).
        if date is None and ALLOW_PUBLISH_DATE_FALLBACK:
            date = parse_publish_date(article_text)
            date_is_approximate = date is not None

        matches = parse_matches_from_text(article_text, url, article_type, giornata_label, date)

        if date_is_approximate:
            for rec in matches:
                rec.validation_flags.append(
                    "DATE_IS_PUBLISH_DATE_APPROXIMATION: no explicit date in title; used article "
                    "publish date as an approximation, which may be off by a day or more"
                )

        if not matches:
            error_log_rows.append({"url": url, "issue": "NO_MATCHES_PARSED — likely not a match-report article"})
        else:
            all_matches.extend(matches)
            for rec in matches:
                for flag in rec.validation_flags:
                    error_log_rows.append({"url": url, "issue": flag})

        if article_type == "TABELLINI" and players_csv:
            players = parse_player_points(article_text, url, matches)
            all_players.extend(players)

    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "season", "giornata_label", "date", "home_team", "away_team",
            "home_sets", "away_sets", "winner", "set_scores",
            "source_url", "article_type", "validation_flags",
        ])
        for rec in all_matches:
            writer.writerow([
                season_label, rec.giornata_label, rec.date, rec.home_team, rec.away_team,
                rec.home_sets, rec.away_sets, rec.winner, rec.set_scores,
                rec.source_url, rec.article_type, "; ".join(rec.validation_flags),
            ])
    log.info("Wrote %d match rows to %s", len(all_matches), out_csv)

    if players_csv:
        with open(players_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["season", "team", "player_name", "points", "source_url"])
            for p in all_players:
                writer.writerow([season_label, p.team, p.player_name, p.points, p.source_url])
        log.info("Wrote %d player-point rows to %s", len(all_players), players_csv)

    with open(log_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "issue"])
        for row in error_log_rows:
            writer.writerow([row["url"], row["issue"]])
    log.info("Wrote %d validation/error log rows to %s", len(error_log_rows), log_csv)

    log.info("Discovery crawl done. URLs processed: %d. Matches parsed: %d. Errors/flags logged: %d.",
              len(urls), len(all_matches), len(error_log_rows))


def main():
    if DIAGNOSTIC_ONLY:
        print_robots_diagnostic(START_URL)
        return

    if DISCOVERY_MODE:
        category_template = "https://www.legavolley.it/category/superlega/page/{page}/"
        urls = discover_article_urls(category_template, CATEGORY_START_PAGE, CATEGORY_END_PAGE, SLEEP_SECONDS)
        log.info("Discovered %d candidate article URLs across pages %d-%d",
                  len(urls), CATEGORY_START_PAGE, CATEGORY_END_PAGE)
        crawl_discovered_urls(
            urls=urls,
            season_label=SEASON_LABEL,
            sleep_seconds=SLEEP_SECONDS,
            out_csv=DISCOVERY_OUT_CSV,
            players_csv=DISCOVERY_PLAYERS_OUT_CSV,
            log_csv=DISCOVERY_LOG_OUT_CSV,
        )
        return

    crawl(
        start_url=START_URL,
        direction=DIRECTION,
        season_label=SEASON_LABEL,
        max_pages=MAX_PAGES,
        sleep_seconds=SLEEP_SECONDS,
        out_csv=OUT_CSV,
        players_csv=PLAYERS_OUT_CSV,
        log_csv=LOG_OUT_CSV,
    )


# Guard against ipykernel/Colab injecting its own sys.argv (e.g. "-f
# /tmp/kernel.json") — we don't use argparse anymore, so this is just a
# normal function call and is safe to run directly in a notebook cell.
if __name__ == "__main__":
    main()
