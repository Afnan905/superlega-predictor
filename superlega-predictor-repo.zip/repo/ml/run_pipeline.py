"""
run_pipeline.py

Runs the full Phase 3 pipeline against the real database:
  1. Loads all matches with a known date.
  2. Computes Elo ratings and writes full history to the team_ratings table.
  3. Builds the feature table and exports it to features.csv for the
     upcoming model-training phase.

USAGE:
    python run_pipeline.py
"""

import csv
import sqlite3
from dataclasses import asdict

from elo import compute_elo_ratings
from features import build_features, load_matches_from_db

DB_PATH = "/home/claude/superlega.db"
FEATURES_OUT_CSV = "/home/claude/ml/features.csv"


def persist_elo_ratings(db_path: str, matches: list):
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("DELETE FROM team_ratings")  # idempotent re-run

    sorted_matches = sorted(matches, key=lambda m: (m["date"], m["match_id"]))
    records = compute_elo_ratings(sorted_matches)

    for r in records:
        conn.execute(
            """INSERT INTO team_ratings
               (team_id, match_id, rating_before, rating_after, expected_result, actual_result, rating_change)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (r.team_id, r.match_id, r.rating_before, r.rating_after,
             r.expected_result, r.actual_result, r.rating_change),
        )
    conn.commit()
    n = conn.execute("SELECT COUNT(*) FROM team_ratings").fetchone()[0]
    print(f"Wrote {n} team_ratings rows to {db_path}")
    conn.close()


def export_features_csv(features: list, out_path: str):
    if not features:
        print("No features to export.")
        return
    fieldnames = list(asdict(features[0]).keys())
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for feat in features:
            writer.writerow(asdict(feat))
    print(f"Wrote {len(features)} feature rows to {out_path}")


def main():
    matches = load_matches_from_db(DB_PATH)
    print(f"Loaded {len(matches)} matches with known dates.")

    persist_elo_ratings(DB_PATH, matches)

    features = build_features(matches)
    export_features_csv(features, FEATURES_OUT_CSV)

    n_with_full_rolling_stats = sum(1 for f in features if f.home_last3_wins is not None and f.away_last3_wins is not None)
    n_with_approx_date = sum(1 for f in features if f.date_is_approximate)
    print(f"\n{n_with_full_rolling_stats}/{len(features)} matches have full last-3 rolling form for both teams.")
    print(f"{n_with_approx_date}/{len(features)} matches used an approximate (publish-date fallback) date.")


if __name__ == "__main__":
    main()
