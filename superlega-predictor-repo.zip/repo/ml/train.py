"""
train.py

Phase 5/6/7: trains a baseline Logistic Regression model, then compares it
against XGBoost, using CHRONOLOGICAL train/validation/test splits (never a
random split — see project brief, section 9).

USAGE:
    pip install scikit-learn xgboost pandas numpy
    python train.py

Requires ml/features.csv (produced by run_pipeline.py) to exist.
"""

import json
import pickle
import sqlite3
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss, log_loss

try:
    from xgboost import XGBClassifier
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False
    print("WARNING: xgboost not installed — run `pip install xgboost` to enable "
          "the XGBoost comparison. Continuing with logistic regression only.")

FEATURES_CSV = "features.csv"
DB_PATH = "superlega.db"   # NOTE: flat path — upload features.csv, superlega.db, and this
                            # script all into the same Colab folder (no subfolders needed)

from features import FEATURE_COLUMNS, LABEL_COLUMN


def season_based_split(df: pd.DataFrame, train_seasons: list, val_season: str, test_season: str = None):
    """
    The brief's originally-intended split structure (section 9): train on
    earlier seasons, validate on the most recent season, test on a further
    separate period where possible. We don't yet have 2022-23, so the
    "closest valid chronological structure" (as the brief allows for) is:
    train on 2023-24 + 2024-25, validate on 2025-26. Since 2025-26 itself
    spans a real season in progress, it's further split into an early
    validation slice and a later test slice, chronologically.
    """
    df = df.sort_values(["date", "match_id"]).reset_index(drop=True)
    train = df[df["season"].isin(train_seasons)]
    remaining = df[df["season"] == val_season].sort_values(["date", "match_id"])

    if test_season and test_season != val_season:
        val = remaining
        test = df[df["season"] == test_season].sort_values(["date", "match_id"])
    else:
        # Split the validation season itself chronologically: first ~60%
        # as true validation, last ~40% as a held-out test.
        n = len(remaining)
        cut = int(n * 0.6)
        val = remaining.iloc[:cut]
        test = remaining.iloc[cut:]

    if len(train) and len(val):
        assert train["date"].max() <= val["date"].min(), "LEAKAGE: train overlaps val in time"
    if len(val) and len(test):
        assert val["date"].max() <= test["date"].min(), "LEAKAGE: val overlaps test in time"

    return train, val, test


def chronological_split(df: pd.DataFrame, train_frac=0.7, val_frac=0.15):
    """
    Splits by DATE ORDER, never randomly (project brief, section 9: "Do NOT
    randomly split matches into training and testing"). With this small a
    dataset, a fixed calendar boundary (e.g. "everything before March") isn't
    meaningful yet, so we use a fractional chronological split instead and
    report the exact resulting date ranges — this is the "closest valid
    chronological structure" the brief allows for when the ideal season-based
    split isn't yet supported by the available data.
    """
    df = df.sort_values(["date", "match_id"]).reset_index(drop=True)
    n = len(df)
    n_train = int(n * train_frac)
    n_val = int(n * val_frac)
    train = df.iloc[:n_train]
    val = df.iloc[n_train:n_train + n_val]
    test = df.iloc[n_train + n_val:]

    # Hard assertion, not just a comment: verify no chronological leakage
    # across the split boundaries before proceeding.
    if len(train) and len(val):
        assert train["date"].max() <= val["date"].min(), "LEAKAGE: train overlaps val in time"
    if len(val) and len(test):
        assert val["date"].max() <= test["date"].min(), "LEAKAGE: val overlaps test in time"

    return train, val, test


def prepare_xy(df: pd.DataFrame, imputer: SimpleImputer, fit: bool):
    X_raw = df[FEATURE_COLUMNS].to_numpy(dtype=float)
    X = imputer.fit_transform(X_raw) if fit else imputer.transform(X_raw)
    y = df[LABEL_COLUMN].to_numpy(dtype=int)
    return X, y


def evaluate(model, X, y, label: str) -> dict:
    if len(y) == 0:
        print(f"  [{label}] no rows — skipping evaluation")
        return {}
    proba = model.predict_proba(X)[:, 1]
    preds = (proba >= 0.5).astype(int)

    metrics = {
        "n": len(y),
        "accuracy": accuracy_score(y, preds),
        "log_loss": log_loss(y, proba, labels=[0, 1]) if len(set(y)) > 1 else None,
        "brier_score": brier_score_loss(y, proba),
    }
    print(f"  [{label}] n={metrics['n']} accuracy={metrics['accuracy']:.3f} "
          f"log_loss={metrics['log_loss']} brier={metrics['brier_score']:.4f}")
    return metrics


def calibration_check(model, X, y, n_bins=5):
    """Groups predictions into probability bins and compares predicted vs
    actual win rate per bin — the brief's calibration requirement. With this
    little data, bins will be sparse; reported honestly rather than padded."""
    if len(y) == 0:
        return []
    proba = model.predict_proba(X)[:, 1]
    bins = np.linspace(0, 1, n_bins + 1)
    bin_idx = np.digitize(proba, bins) - 1
    rows = []
    for b in range(n_bins):
        mask = bin_idx == b
        if mask.sum() == 0:
            continue
        rows.append({
            "bin_range": f"{bins[b]:.1f}-{bins[b+1]:.1f}",
            "n": int(mask.sum()),
            "avg_predicted": float(proba[mask].mean()),
            "actual_win_rate": float(y[mask].mean()),
        })
    return rows


def save_model_run(db_path, model_version, model_type, training_seasons, features,
                    val_season, test_season, metrics_val, metrics_test, notes, calibration=None):
    conn = sqlite3.connect(db_path)
    conn.execute("""
        INSERT OR REPLACE INTO model_runs
        (model_version, model_type, training_date, training_seasons, validation_season, test_season,
         features, accuracy, log_loss, brier_score, num_train_matches, num_val_matches, num_test_matches,
         calibration, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        model_version, model_type, datetime.now(timezone.utc).isoformat(), training_seasons,
        val_season, test_season, json.dumps(features),
        metrics_test.get("accuracy"), metrics_test.get("log_loss"), metrics_test.get("brier_score"),
        metrics_val.get("_n_train"), metrics_val.get("n"), metrics_test.get("n"),
        json.dumps(calibration) if calibration is not None else None, notes,
    ))
    conn.commit()
    conn.close()


def save_deployed_model(model, imputer, model_version: str, feature_columns: list, out_path="deployed_model.pkl"):
    """
    Persists the fitted model + imputer + feature-column order, so the
    prediction API can load a ready-to-use model without retraining.
    Only the CHOSEN model (winner of the comparison) should be saved here
    — per the brief, don't assume the more complex model is better; save
    whichever one actually won on validation/test metrics.
    """
    with open(out_path, "wb") as f:
        pickle.dump({
            "model": model,
            "imputer": imputer,
            "model_version": model_version,
            "feature_columns": feature_columns,
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }, f)
    print(f"Saved deployed model ({model_version}) to {out_path}")


def main():
    df = pd.read_csv(FEATURES_CSV)
    print(f"Loaded {len(df)} rows from {FEATURES_CSV}")

    train_df, val_df, test_df = season_based_split(
        df, train_seasons=["2022-23", "2023-24", "2024-25"], val_season="2025-26"
    )
    print(f"\nChronological split:")
    print(f"  Train: {len(train_df)} matches, {train_df['date'].min()} to {train_df['date'].max()}" if len(train_df) else "  Train: empty")
    print(f"  Val:   {len(val_df)} matches, {val_df['date'].min()} to {val_df['date'].max()}" if len(val_df) else "  Val: empty")
    print(f"  Test:  {len(test_df)} matches, {test_df['date'].min()} to {test_df['date'].max()}" if len(test_df) else "  Test: empty")

    imputer = SimpleImputer(strategy="mean")
    X_train, y_train = prepare_xy(train_df, imputer, fit=True)
    X_val, y_val = prepare_xy(val_df, imputer, fit=False)
    X_test, y_test = prepare_xy(test_df, imputer, fit=False)

    print(f"\n=== Logistic Regression (baseline) ===")
    logreg = LogisticRegression(max_iter=1000)
    logreg.fit(X_train, y_train)
    val_metrics = evaluate(logreg, X_val, y_val, "val")
    test_metrics = evaluate(logreg, X_test, y_test, "test")
    val_metrics["_n_train"] = len(y_train)
    calib = calibration_check(logreg, X_test, y_test)
    print(f"  calibration (test): {calib}")

    save_model_run(
        DB_PATH, "logreg-v1", "logistic_regression",
        training_seasons="2022-23, 2023-24, 2024-25",
        features=FEATURE_COLUMNS,
        val_season="2025-26 (first 60%% chronologically)",
        test_season="2025-26 (final 40%% chronologically)",
        metrics_val=val_metrics, metrics_test=test_metrics,
        notes="Baseline model. Trained on full 2022-23 + 2023-24 + 2024-25 "
              "seasons (890 matches), validated/tested on 2025-26. Uses "
              "real season-based chronological split.",
        calibration=calib,
    )

    # logreg-v1 was empirically found to match or beat xgboost-v1 on test
    # log_loss/brier score (see model_runs table) — per the brief's
    # instruction not to assume the more complex model is better, this is
    # the model actually deployed for predictions.
    save_deployed_model(logreg, imputer, "logreg-v1", FEATURE_COLUMNS)

    if HAS_XGBOOST:
        print(f"\n=== XGBoost ===")
        xgb = XGBClassifier(
            n_estimators=100, max_depth=3, learning_rate=0.1,
            eval_metric="logloss", use_label_encoder=False,
        )
        xgb.fit(X_train, y_train)
        val_metrics_xgb = evaluate(xgb, X_val, y_val, "val")
        test_metrics_xgb = evaluate(xgb, X_test, y_test, "test")
        val_metrics_xgb["_n_train"] = len(y_train)

        save_model_run(
            DB_PATH, "xgboost-v1", "xgboost",
            training_seasons="2022-23, 2023-24, 2024-25",
            features=FEATURE_COLUMNS,
            val_season="2025-26 (first 60%% chronologically)",
            test_season="2025-26 (final 40%% chronologically)",
            metrics_val=val_metrics_xgb, metrics_test=test_metrics_xgb,
            notes="Compared against logreg-v1 baseline. Same 3-season "
                  "training/validation structure.",
        )

        print(f"\n=== Comparison ===")
        print(f"  LogReg  test accuracy: {test_metrics.get('accuracy')}")
        print(f"  XGBoost test accuracy: {test_metrics_xgb.get('accuracy')}")
        if test_metrics.get("log_loss") is not None and test_metrics_xgb.get("log_loss") is not None:
            better = "XGBoost" if test_metrics_xgb["log_loss"] < test_metrics["log_loss"] else "Logistic Regression"
            print(f"  Lower log_loss (better): {better}")
    else:
        print("\nSkipping XGBoost comparison — library not installed in this environment.")


if __name__ == "__main__":
    main()
