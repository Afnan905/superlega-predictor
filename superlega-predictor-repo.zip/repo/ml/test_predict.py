"""
test_predict.py

Automated tests for predict.py: probability validity, alias resolution,
and error handling. Run with: python test_predict.py

Requires superlega.db and deployed_model.pkl to exist in this folder
(run train.py first if they don't).
"""

import sys
import sqlite3

from predict import predict_match

DB_PATH = "superlega.db"
MODEL_PATH = "deployed_model.pkl"


def test_probabilities_valid_range_and_sum():
    result = predict_match("Itas Trentino", "Cucine Lube Civitanova", model_path=MODEL_PATH, db_path=DB_PATH)
    assert 0 <= result["home_win_probability"] <= 1
    assert 0 <= result["away_win_probability"] <= 1
    total = result["home_win_probability"] + result["away_win_probability"]
    assert abs(total - 1.0) < 0.001, f"probabilities should sum to 1, got {total}"


def test_predicted_winner_matches_higher_probability():
    result = predict_match("Itas Trentino", "Cucine Lube Civitanova", model_path=MODEL_PATH, db_path=DB_PATH)
    if result["home_win_probability"] >= 0.5:
        assert result["predicted_winner"] == result["home_team"]
    else:
        assert result["predicted_winner"] == result["away_team"]


def test_alias_resolves_to_canonical_name():
    result = predict_match("Autopancotti Vero Volley Monza", "Sir Sicoma Monini Perugia",
                            model_path=MODEL_PATH, db_path=DB_PATH)
    assert result["home_team"] == "Vero Volley Monza"
    assert result["away_team"] == "Sir Susa Scai Perugia"


def test_same_team_rejected():
    try:
        predict_match("Itas Trentino", "Itas Trentino", model_path=MODEL_PATH, db_path=DB_PATH)
        assert False, "should have raised ValueError"
    except ValueError:
        pass


def test_unknown_team_rejected():
    try:
        predict_match("Nonexistent Team FC", "Itas Trentino", model_path=MODEL_PATH, db_path=DB_PATH)
        assert False, "should have raised ValueError"
    except ValueError:
        pass


def test_valid_probabilities_across_all_teams():
    """Every real team paired against every other real team should produce
    a valid probability pair — a broader sweep than the single-pair checks
    above, closer to what the brief's 'Prediction probabilities' testing
    requirement is asking for."""
    conn = sqlite3.connect(DB_PATH)
    teams = [r[0] for r in conn.execute("SELECT canonical_name FROM teams").fetchall()]
    conn.close()

    checked = 0
    for i in range(len(teams)):
        for j in range(len(teams)):
            if i == j:
                continue
            result = predict_match(teams[i], teams[j], model_path=MODEL_PATH, db_path=DB_PATH)
            assert 0 <= result["home_win_probability"] <= 1
            assert 0 <= result["away_win_probability"] <= 1
            total = result["home_win_probability"] + result["away_win_probability"]
            assert abs(total - 1.0) < 0.001
            checked += 1
    print(f"  (checked {checked} team-pair combinations, all valid)")


def test_current_elo_is_nonnegative():
    result = predict_match("Farmitalia Catania", "Emma Villas Aubay Siena",
                            model_path=MODEL_PATH, db_path=DB_PATH)
    assert result["home_current_elo"] > 0
    assert result["away_current_elo"] > 0


def test_supporting_stats_present_and_sane():
    result = predict_match("Sir Susa Scai Perugia", "Gas Sales Bluenergy Piacenza",
                            model_path=MODEL_PATH, db_path=DB_PATH)
    stats = result["supporting_stats"]
    assert "home" in stats and "away" in stats and "head_to_head" in stats
    assert "recent_form_last3" in stats["home"]
    h2h = stats["head_to_head"]
    if h2h["home_wins"] is not None and h2h["away_wins"] is not None:
        assert h2h["home_wins"] >= 0 and h2h["away_wins"] >= 0


def test_team_profile_sane_numbers():
    from predict import get_team_profile
    profile = get_team_profile("Sir Susa Scai Perugia", db_path=DB_PATH)
    assert profile["wins"] + profile["losses"] == profile["matches_played"]
    assert profile["home_record"]["wins"] + profile["away_record"]["wins"] == profile["wins"]
    assert profile["current_elo"] > 0


ALL_TESTS = [
    test_probabilities_valid_range_and_sum,
    test_predicted_winner_matches_higher_probability,
    test_alias_resolves_to_canonical_name,
    test_same_team_rejected,
    test_unknown_team_rejected,
    test_valid_probabilities_across_all_teams,
    test_current_elo_is_nonnegative,
    test_supporting_stats_present_and_sane,
    test_team_profile_sane_numbers,
]

if __name__ == "__main__":
    passed, failed = 0, 0
    for test in ALL_TESTS:
        try:
            test()
            print(f"PASS: {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"FAIL: {test.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
