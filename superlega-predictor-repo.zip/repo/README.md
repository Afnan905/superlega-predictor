# SuperLega Predictor

Machine-learning win-probability predictions for the Italian men's professional volleyball
league (SuperLega). Built end-to-end: a validated web scraper, a relational database of 1,100+
real matches across four seasons, leakage-safe feature engineering, a Logistic Regression vs.
XGBoost model comparison, a FastAPI backend, and a React/TypeScript dashboard.

**[Read the project write-up →](https://YOUR-GITHUB-USERNAME.github.io/superlega-predictor/)**
*(replace with your actual GitHub Pages URL once published — see "Publishing this repo" below)*

---

## Why this project

Most "ML sports predictor" projects either fabricate data or skip the hard parts (data
validation, leakage prevention, honest model comparison). This one doesn't:

- **No invented data.** Every match was scraped from a real source, validated, and — where
  something looked wrong — flagged and excluded rather than silently guessed at. See
  [`data/data_sources_report.md`](data/data_sources_report.md) for the full data-sourcing
  investigation.
- **Leakage prevention is tested, not assumed.** [`ml/test_features.py`](ml/test_features.py)
  includes tests that explicitly prove a match's features never include information from a
  later match.
- **The simpler model won, and that's what's deployed.** Logistic Regression and XGBoost were
  compared on a real chronological train/validation/test split (train on 2022-23 through
  2024-25, validate/test on 2025-26). XGBoost did not outperform the baseline, so the baseline
  is what's in production — not because complexity was avoided, but because it was checked.

## Architecture

```
legavolley.it  →  scraper/  →  database/  →  ml/  →  backend/  →  frontend/
  (raw HTML)      (validated    (SQLite,      (Elo,     (FastAPI    (React +
                   CSV batches)  1,111         features,  API)       TypeScript
                                 matches)      LogReg)               dashboard)
```

| Folder | What's in it |
|---|---|
| [`scraper/`](scraper/) | Python scraper for legavolley.it — discovery-mode category-archive crawling, retry/backoff, team-name whitelist validation |
| [`data/`](data/) | Raw scraped CSV batches (pre-validation) and the data-sourcing investigation report |
| [`database/`](database/) | SQLite schema (+ a Postgres variant), the CSV-to-database loader with validation, and the populated database itself |
| [`ml/`](ml/) | Elo rating system, chronological feature engineering, model training/comparison, prediction logic, automated tests |
| [`backend/`](backend/) | FastAPI app exposing predictions, team profiles, and model performance |
| [`frontend/`](frontend/) | React + TypeScript + Tailwind CSS dashboard |
| [`docs/`](docs/) | The GitHub Pages project write-up (this repo's live site) |

## Results

- **1,111 real matches** scraped and validated across the 2022-23, 2023-24, 2024-25, and
  2025-26 seasons
- **Test log loss: 0.636** (Logistic Regression, trained on 890 matches, tested on held-out
  2025-26 data)
- XGBoost comparison: same accuracy, slightly worse log loss and Brier score — logged and kept
  as the honest result, not discarded

## Running it yourself

Each folder has what it needs to run independently:

1. **Database** is already populated (`database/superlega.db`) — no setup needed to explore it.
2. **Backend**: `cd backend && pip install fastapi uvicorn scikit-learn pandas numpy && uvicorn main:app --reload`
3. **Frontend**: `cd frontend && npm install && cp .env.example .env && npm run dev`
4. **Re-running the ML pipeline**: `cd ml && python run_pipeline.py && python train.py`
5. **Re-scraping**: `scraper/legavolley_scraper.py` has a `CONFIG` block at the top — see inline
   comments for discovery-mode usage.

Full setup details are in each folder's own README where present, and inline in each script's
module docstring otherwise.

## Publishing this repo (for the maintainer)

To turn this into a live site at `https://<your-username>.github.io/superlega-predictor/`:

```bash
git init
git add .
git commit -m "Initial commit: SuperLega Predictor"
git branch -M main
git remote add origin https://github.com/<your-username>/superlega-predictor.git
git push -u origin main
```

Then on GitHub: **Settings → Pages → Source: Deploy from a branch → Branch: `main`, folder:
`/docs`**. GitHub will publish `docs/index.html` as a live site within a minute or two.

## A note on the data

Match results, dates, and team names are factual, not creative works, and generally aren't
copyrightable — but if you plan to redistribute the *bulk scraped dataset* itself (not just the
code), it's worth checking legavolley.it's terms of service first. Publishing the scraper code
and the schema is unambiguous; publishing a large bulk dataset scraped from a specific site is a
separate consideration.

## License

MIT — see [LICENSE](LICENSE). Data collected from legavolley.it is subject to that site's own
terms, independent of this repo's code license.
