"""
load_matches.py

Loads matches_2025_26.csv / players_2025_26.csv (output from
legavolley_scraper.py) into the SQLite database defined by
schema_sqlite.sql.

RULES (matching the project's core data-integrity requirement):
  - Rows from matches CSV with NO validation_flags are imported as trusted.
  - Rows WITH validation_flags are NOT imported into matches/team_match_
    statistics — they're written to ingestion_log instead, so nothing
    flagged as suspicious silently enters the training data.
  - Team names are resolved through team_name_aliases. An unrecognized team
    name is logged to ingestion_log and the row is skipped — never
    auto-created as a new team, since that risks silently splitting one
    real club into two different team_ids over a name variant.

USAGE:
    python load_matches.py
(edit the CONFIG block below to point at different CSV files or DB path)
"""

import csv
import json
import sqlite3
from pathlib import Path

# =============================================================================
# CONFIG
# =============================================================================
DB_PATH = "superlega.db"
SCHEMA_PATH = "schema_sqlite.sql"
MATCHES_CSV = "matches_2025_26.csv"
PLAYERS_CSV = "players_2025_26.csv"
SEASON_NAME = "2025-26"
SOURCE_LABEL = "legavolley.it"

# All flag name prefixes the scraper can emit (see legavolley_scraper.py's
# validation_flags). Detected via substring containment rather than
# splitting the raw string on ";" — a flag's own descriptive text can
# itself contain a semicolon (e.g. "...in title; used article publish
# date..."), which broke a naive split-based approach: it produced a
# second, unrecognized pseudo-flag from the tail of the sentence and caused
# every date-approximated row to be wrongly treated as hard-rejected.
ALL_FLAG_NAMES = [
    "MISSING_TEAM_NAME",
    "SUSPICIOUS_TEAM_NAME",
    "NOT_RECOGNIZED_TEAM",
    "IMPOSSIBLE_RESULT",
    "UNUSUAL_RESULT",
    "MISSING_DATE",
    "DATE_IS_PUBLISH_DATE_APPROXIMATION",
]

# Flags that mean "this row is trustworthy but has one known limitation" —
# still imported, with the limitation recorded, not silently hidden.
SOFT_FLAGS = {"DATE_IS_PUBLISH_DATE_APPROXIMATION"}
# Any OTHER flag (SUSPICIOUS_TEAM_NAME, NOT_RECOGNIZED_TEAM, UNUSUAL_RESULT,
# MISSING_TEAM_NAME, etc.) is a hard reject — logged, not imported.
# =============================================================================


def get_hard_flags(raw_flags: str) -> set:
    present = {name for name in ALL_FLAG_NAMES if name in raw_flags}
    return present - SOFT_FLAGS

# Canonical team names + known aliases, built from what's been directly
# confirmed in scraped data so far. Extend this as more aliases are observed
# in future seasons/sources.
CANONICAL_TEAMS = [
    "Cucine Lube Civitanova",
    "Yuasa Battery Grottazzolina",
    "Rana Verona",
    "Gas Sales Bluenergy Piacenza",
    "Allianz Milano",
    "Valsa Group Modena",
    "Cisterna Volley",
    "Itas Trentino",
    "Sonepar Padova",
    "MA Acqua S.Bernardo Cuneo",
    "Vero Volley Monza",
    "Sir Susa Scai Perugia",
    "Gioiella Prisma Taranto",  # 2024-25 season team, not in 2025-26 league
    "Farmitalia Catania",  # 2023-24 season team, first-ever SuperLega appearance
    "Emma Villas Aubay Siena",  # 2022-23 season team, relegated after that season
]

TEAM_ALIASES = {
    # alias -> canonical name
    "Autopancotti Vero Volley Monza": "Vero Volley Monza",
    "Sir Sicoma Monini Perugia": "Sir Susa Scai Perugia",
    "Trentino Itas": "Itas Trentino",
    "Gas Sales Bluenergy Volley Piacenza": "Gas Sales Bluenergy Piacenza",
    "Sir Susa Vim Perugia": "Sir Susa Scai Perugia",  # 2024-25 sponsor variant
    "Mint Vero Volley Monza": "Vero Volley Monza",     # 2024-25 sponsor variant
    "Pallavolo Padova": "Sonepar Padova",  # 2023-24 sponsor name
    "Gas Sales Daiko Piacenza": "Gas Sales Bluenergy Piacenza",  # 2023-24 sponsor variant
    "WithU Verona": "Rana Verona",  # 2022-23 sponsor variant
    "Top Volley Cisterna": "Cisterna Volley",  # 2022-23 sponsor variant
    "Sir Safety Susa Perugia": "Sir Susa Scai Perugia",  # 2022-23 sponsor variant
    "Sir Safety Conad Perugia": "Sir Susa Scai Perugia",  # 2022-23 mid-season sponsor variant
    "Emma Villas Siena": "Emma Villas Aubay Siena",  # shortened form
}


def init_db(conn: sqlite3.Connection):
    schema_sql = Path(SCHEMA_PATH).read_text()
    conn.executescript(schema_sql)


def seed_teams(conn: sqlite3.Connection) -> dict:
    """Inserts canonical teams + aliases if not already present. Returns a
    dict mapping every known raw name (canonical or alias) -> team_id."""
    cur = conn.cursor()
    name_to_id = {}

    for name in CANONICAL_TEAMS:
        cur.execute(
            "INSERT OR IGNORE INTO teams (canonical_name) VALUES (?)", (name,)
        )
    conn.commit()

    for name in CANONICAL_TEAMS:
        row = cur.execute(
            "SELECT id FROM teams WHERE canonical_name = ?", (name,)
        ).fetchone()
        name_to_id[name] = row[0]

    for alias, canonical in TEAM_ALIASES.items():
        team_id = name_to_id[canonical]
        cur.execute(
            "INSERT OR IGNORE INTO team_name_aliases (team_id, alias, season, source) "
            "VALUES (?, ?, ?, ?)",
            (team_id, alias, None, SOURCE_LABEL),  # season varies per-alias now; not tracked per-row here
        )
        name_to_id[alias] = team_id
    conn.commit()

    return name_to_id


def seed_season(conn: sqlite3.Connection, season_name: str) -> int:
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO seasons (name) VALUES (?)", (season_name,))
    conn.commit()
    return cur.execute(
        "SELECT id FROM seasons WHERE name = ?", (season_name,)
    ).fetchone()[0]


def log_issue(conn: sqlite3.Connection, source_ref: str, raw_row: dict, issue: str):
    conn.execute(
        "INSERT INTO ingestion_log (source, source_ref, raw_row, issue) VALUES (?, ?, ?, ?)",
        ("csv_upload", source_ref, json.dumps(raw_row, ensure_ascii=False), issue),
    )


def resolve_team_id(raw_name: str, team_ids: dict):
    """Case-insensitive lookup against known teams/aliases. The scraper's
    own whitelist check is already case-insensitive (team_is_recognized),
    so this matches that leniency rather than being stricter than the
    validation that already approved the row."""
    if raw_name in team_ids:
        return team_ids[raw_name]
    raw_low = raw_name.strip().lower()
    for name, tid in team_ids.items():
        if name.lower() == raw_low:
            return tid
    return None


def load_matches(conn: sqlite3.Connection, team_ids: dict, season_id: int, matches_csv: str = None):
    matches_csv = matches_csv or MATCHES_CSV
    imported, skipped_flagged, skipped_unresolved_team, skipped_missing_date = 0, 0, 0, 0

    with open(matches_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            raw_flags = (row.get("validation_flags") or "").strip()
            hard_flags = get_hard_flags(raw_flags)

            if hard_flags:
                log_issue(conn, row.get("source_url", ""), row, f"SKIPPED_FLAGGED_ROW: {raw_flags}")
                skipped_flagged += 1
                continue

            date_is_approximate = "DATE_IS_PUBLISH_DATE_APPROXIMATION" in raw_flags

            home_raw, away_raw = row["home_team"], row["away_team"]
            home_id = resolve_team_id(home_raw, team_ids)
            away_id = resolve_team_id(away_raw, team_ids)
            if home_id is None or away_id is None:
                log_issue(
                    conn, row.get("source_url", ""), row,
                    f"UNRESOLVED_TEAM_NAME: '{home_raw}' or '{away_raw}' not in known teams/aliases"
                )
                skipped_unresolved_team += 1
                continue

            if not row.get("date"):
                log_issue(conn, row.get("source_url", ""), row, "SKIPPED_MISSING_DATE")
                skipped_missing_date += 1
                continue

            winner_id = resolve_team_id(row.get("winner", ""), team_ids)

            try:
                conn.execute(
                    """INSERT INTO matches
                       (season_id, giornata_label, date, date_is_approximate, home_team_id, away_team_id,
                        home_sets, away_sets, winner_team_id, set_scores, source, source_url)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        season_id, row.get("giornata_label"), row["date"], int(date_is_approximate),
                        home_id, away_id, int(row["home_sets"]), int(row["away_sets"]), winner_id,
                        row.get("set_scores"), SOURCE_LABEL, row.get("source_url"),
                    ),
                )
                imported += 1
            except sqlite3.IntegrityError as e:
                log_issue(conn, row.get("source_url", ""), row, f"DB_CONSTRAINT_REJECTED: {e}")

    conn.commit()
    print(f"[{matches_csv}] Matches imported: {imported}")
    print(f"[{matches_csv}] Skipped (had hard validation flags): {skipped_flagged}")
    print(f"[{matches_csv}] Skipped (unresolved team name): {skipped_unresolved_team}")
    print(f"[{matches_csv}] Skipped (missing date): {skipped_missing_date}")


def load_player_points(conn: sqlite3.Connection, team_ids: dict, season_id: int, players_csv: str = None):
    players_csv = players_csv or PLAYERS_CSV
    if not Path(players_csv).exists():
        print(f"No {players_csv} found, skipping player points.")
        return

    imported, skipped = 0, 0
    with open(players_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            team_raw = row["team"]
            team_id = resolve_team_id(team_raw, team_ids)
            if team_id is None:
                log_issue(conn, row.get("source_url", ""), row,
                          f"UNRESOLVED_TEAM_NAME (player row): '{team_raw}'")
                skipped += 1
                continue
            match = conn.execute(
                "SELECT id FROM matches WHERE source_url = ?", (row.get("source_url"),)
            ).fetchone()
            if not match:
                # This is expected/benign: the player's match row may have
                # been one of the ones skipped above (flagged/unresolved),
                # so there's nothing to attach these points to. Not an error.
                skipped += 1
                continue
            conn.execute(
                "INSERT INTO match_player_points (match_id, team_id, player_name, points) "
                "VALUES (?, ?, ?, ?)",
                (match[0], team_id, row["player_name"],
                 int(row["points"]) if row.get("points") not in (None, "") else None),
            )
            imported += 1
    conn.commit()
    print(f"[{players_csv}] Player-point rows imported: {imported}")
    print(f"[{players_csv}] Player-point rows skipped (no matching imported match): {skipped}")


# Every known (matches_csv, players_csv) pair to load, in order. Add more
# pairs here as new scraper runs (chain-walk, discovery-mode batches for
# different page ranges, other seasons, etc.) produce output files.
#
# IMPORTANT: give each batch a distinct filename (e.g. matches_feb_2026.csv,
# not a reused generic matches_discovered.csv) before adding it here — the
# scraper's default discovery-mode output filename is the same every run,
# so saving over it silently discards the previous batch. This caused a
# real data-loss near-miss: a March playoff batch (15 matches) was nearly
# lost when a February batch was saved to the same default filename and
# would have been the only one loaded on a fresh rebuild.
DATA_FILE_PAIRS = [
    # (matches_csv, players_csv, season_name)
    ("matches_2025_26.csv", "players_2025_26.csv", "2025-26"),
    ("matches_march_playoffs.csv", None, "2025-26"),
    ("matches_feb_2026.csv", None, "2025-26"),
    ("matches_nov_jan.csv", None, "2025-26"),
    ("matches_2024_25_bulk.csv", None, "2024-25"),
    ("matches_2024_25_feb_mar.csv", None, "2024-25"),
    ("matches_2023_24_bulk.csv", None, "2023-24"),
    ("matches_2023_24_jan.csv", None, "2023-24"),
    ("matches_2022_23_start.csv", None, "2022-23"),
    ("matches_2022_23_novfeb.csv", None, "2022-23"),
    ("matches_2022_23_playoffs_corrected.csv", None, "2022-23"),
]


def update_active_teams(conn: sqlite3.Connection):
    """
    A team is 'active' if it played in the most recent season on record.
    Without this, every team defaults to active=1 forever (including
    long-relegated teams like Farmitalia Catania, which only ever played
    in 2023-24) — this derives the correct value from real match
    participation instead of trusting a static default.
    """
    latest_season = conn.execute(
        "SELECT name FROM seasons ORDER BY name DESC LIMIT 1"
    ).fetchone()
    if not latest_season:
        return
    conn.execute("UPDATE teams SET active = 0")
    conn.execute("""
        UPDATE teams SET active = 1
        WHERE id IN (
            SELECT DISTINCT home_team_id FROM matches m
            JOIN seasons s ON m.season_id = s.id WHERE s.name = ?
            UNION
            SELECT DISTINCT away_team_id FROM matches m
            JOIN seasons s ON m.season_id = s.id WHERE s.name = ?
        )
    """, (latest_season[0], latest_season[0]))
    conn.commit()


def main():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")

    tables_exist = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='teams'"
    ).fetchone()
    if not tables_exist:
        init_db(conn)
        print(f"Initialized schema in {DB_PATH}")

    team_ids = seed_teams(conn)

    for matches_csv, players_csv, season_name in DATA_FILE_PAIRS:
        if not Path(matches_csv).exists():
            print(f"Skipping {matches_csv} (file not found)")
            continue
        season_id = seed_season(conn, season_name)
        load_matches(conn, team_ids, season_id, matches_csv)
        if players_csv:
            load_player_points(conn, team_ids, season_id, players_csv)

    update_active_teams(conn)

    n_matches = conn.execute("SELECT COUNT(*) FROM matches").fetchone()[0]
    n_log = conn.execute("SELECT COUNT(*) FROM ingestion_log").fetchone()[0]
    print(f"\nDatabase now has {n_matches} matches and {n_log} logged ingestion issues.")
    conn.close()


if __name__ == "__main__":
    main()
