-- =============================================================================
-- SuperLega Predictor — Database Schema (Phase 2)
-- =============================================================================
-- Written in standard PostgreSQL. Portable to any Postgres host: Supabase
-- (free tier), Neon (free tier), a local Postgres install, or Replit's SQL
-- database if you ever go back to it. For quick local testing without any
-- server at all, this also runs on SQLite with minor tweaks (see notes at
-- the bottom of this file).
-- =============================================================================


-- -----------------------------------------------------------------------------
-- teams
-- -----------------------------------------------------------------------------
-- One row per real-world club, using a stable canonical identity that
-- survives sponsor-name changes across seasons (e.g. "Vero Volley Monza" vs
-- "Autopancotti Vero Volley Monza" are the SAME club, different sponsor
-- prefixes in different seasons/articles — confirmed directly during
-- Phase 1 scraping).
-- -----------------------------------------------------------------------------
CREATE TABLE teams (
    id              SERIAL PRIMARY KEY,
    canonical_name  TEXT NOT NULL UNIQUE,   -- e.g. "Vero Volley Monza" (sponsor-neutral)
    abbreviation    TEXT,                    -- e.g. "MON"
    city            TEXT,
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- -----------------------------------------------------------------------------
-- team_name_aliases
-- -----------------------------------------------------------------------------
-- This is the fix for the exact normalization problem the brief calls out
-- ("Sir Safety Perugia" vs "Perugia") and that we've already seen in real
-- scraped data ("Vero Volley Monza" vs "Autopancotti Vero Volley Monza").
-- Every name variant ever seen for a team maps to one canonical team_id.
-- The ingestion pipeline looks up incoming raw names here BEFORE inserting
-- a match; an unrecognized name is logged as an error, never silently
-- guessed at or auto-created.
-- -----------------------------------------------------------------------------
CREATE TABLE team_name_aliases (
    id          SERIAL PRIMARY KEY,
    team_id     INTEGER NOT NULL REFERENCES teams(id),
    alias       TEXT NOT NULL UNIQUE,   -- e.g. "Autopancotti Vero Volley Monza"
    season      TEXT,                    -- optional: which season used this alias, e.g. "2025-26"
    source      TEXT,                    -- where this alias was observed, e.g. "legavolley.it"
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- -----------------------------------------------------------------------------
-- seasons
-- -----------------------------------------------------------------------------
CREATE TABLE seasons (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE,   -- e.g. "2025-26"
    start_date  DATE,
    end_date    DATE,
    is_current  BOOLEAN NOT NULL DEFAULT FALSE
);

-- -----------------------------------------------------------------------------
-- matches
-- -----------------------------------------------------------------------------
CREATE TABLE matches (
    id              SERIAL PRIMARY KEY,
    season_id       INTEGER NOT NULL REFERENCES seasons(id),
    giornata_label  TEXT,                 -- e.g. "1ª Giornata And." — raw label as scraped/entered
    date            DATE,                 -- NULL if not yet confirmed (never guessed)
    home_team_id    INTEGER NOT NULL REFERENCES teams(id),
    away_team_id    INTEGER NOT NULL REFERENCES teams(id),
    home_sets       SMALLINT NOT NULL,
    away_sets       SMALLINT NOT NULL,
    winner_team_id  INTEGER REFERENCES teams(id),
    set_scores      TEXT,                 -- "25-15,25-16,23-25,25-23"
    is_completed    BOOLEAN NOT NULL DEFAULT TRUE,   -- FALSE for scheduled/upcoming matches
    source          TEXT NOT NULL,        -- e.g. "legavolley.it", "manual_csv_upload"
    source_url      TEXT,
    ingested_at     TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT chk_sets_not_tied CHECK (home_sets <> away_sets OR is_completed = FALSE),
    CONSTRAINT chk_sets_range CHECK (home_sets BETWEEN 0 AND 3 AND away_sets BETWEEN 0 AND 3),
    CONSTRAINT chk_different_teams CHECK (home_team_id <> away_team_id),
    -- Prevents the exact kind of accidental duplicate ingestion we saw when
    -- the same Round-22 match was reported across 4 different articles.
    CONSTRAINT uq_match UNIQUE (season_id, date, home_team_id, away_team_id)
);

CREATE INDEX idx_matches_season ON matches(season_id);
CREATE INDEX idx_matches_date ON matches(date);
CREATE INDEX idx_matches_home_team ON matches(home_team_id);
CREATE INDEX idx_matches_away_team ON matches(away_team_id);

-- -----------------------------------------------------------------------------
-- team_match_statistics
-- -----------------------------------------------------------------------------
-- One row per team per match. Columns are nullable because, per Phase 1
-- findings, granular DataVolley-style stats (attack %, block, serve,
-- reception %) are NOT confirmed available in bulk for every historical
-- match — only per-player point totals were reliably extractable so far.
-- Store whatever's genuinely available; never fill gaps with estimates.
-- -----------------------------------------------------------------------------
CREATE TABLE team_match_statistics (
    id                  SERIAL PRIMARY KEY,
    match_id            INTEGER NOT NULL REFERENCES matches(id),
    team_id             INTEGER NOT NULL REFERENCES teams(id),
    is_home             BOOLEAN NOT NULL,
    points_scored_total INTEGER,          -- sum of per-player points, when available
    attack_points       INTEGER,
    attack_errors       INTEGER,
    attack_efficiency   NUMERIC(5,2),     -- percentage, e.g. 45.30
    block_points        INTEGER,
    serve_aces          INTEGER,
    serve_errors        INTEGER,
    reception_positive_pct NUMERIC(5,2),
    reception_perfect_pct  NUMERIC(5,2),
    total_errors        INTEGER,
    data_completeness   TEXT NOT NULL DEFAULT 'partial',  -- 'full' | 'partial' | 'scores_only'

    CONSTRAINT uq_team_match_stat UNIQUE (match_id, team_id)
);

-- -----------------------------------------------------------------------------
-- match_player_points
-- -----------------------------------------------------------------------------
-- The one statistic we DID confirm is reliably extractable from TABELLINI
-- articles: per-player point totals. Kept as its own table since it's a
-- finer grain than team_match_statistics.
-- -----------------------------------------------------------------------------
CREATE TABLE match_player_points (
    id          SERIAL PRIMARY KEY,
    match_id    INTEGER NOT NULL REFERENCES matches(id),
    team_id     INTEGER NOT NULL REFERENCES teams(id),
    player_name TEXT NOT NULL,   -- free text for now; a players table with
                                   -- canonical IDs is a reasonable future
                                   -- addition once name-normalization for
                                   -- players is worth the same treatment
                                   -- teams got above
    points      INTEGER
);

-- -----------------------------------------------------------------------------
-- team_ratings
-- -----------------------------------------------------------------------------
-- Full Elo history, one row per team per match, so any historical
-- prediction can be reproduced exactly using the rating as it stood
-- immediately before that match (never the team's current/final rating).
-- -----------------------------------------------------------------------------
CREATE TABLE team_ratings (
    id                  SERIAL PRIMARY KEY,
    team_id             INTEGER NOT NULL REFERENCES teams(id),
    match_id            INTEGER NOT NULL REFERENCES matches(id),
    rating_before       NUMERIC(7,2) NOT NULL,
    rating_after        NUMERIC(7,2) NOT NULL,
    expected_result     NUMERIC(5,4),     -- Elo expected score, 0-1
    actual_result       NUMERIC(3,2),     -- 1 = win, 0 = loss (no draws in volleyball)
    rating_change       NUMERIC(7,2) NOT NULL,
    computed_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_team_rating_per_match UNIQUE (team_id, match_id)
);

CREATE INDEX idx_team_ratings_team ON team_ratings(team_id);

-- -----------------------------------------------------------------------------
-- model_runs
-- -----------------------------------------------------------------------------
CREATE TABLE model_runs (
    id                SERIAL PRIMARY KEY,
    model_version     TEXT NOT NULL UNIQUE,  -- e.g. "logreg-v1", "xgboost-v1"
    model_type        TEXT NOT NULL,          -- "logistic_regression" | "xgboost"
    training_date     TIMESTAMPTZ NOT NULL,
    training_seasons  TEXT NOT NULL,          -- e.g. "2022-23,2023-24,2024-25"
    validation_season TEXT,
    test_season       TEXT,
    features          JSONB NOT NULL,         -- list of feature names used
    accuracy          NUMERIC(5,4),
    log_loss          NUMERIC(7,4),
    brier_score       NUMERIC(7,4),
    num_train_matches INTEGER,
    num_val_matches   INTEGER,
    num_test_matches  INTEGER,
    notes             TEXT
);

-- -----------------------------------------------------------------------------
-- predictions
-- -----------------------------------------------------------------------------
CREATE TABLE predictions (
    id                  SERIAL PRIMARY KEY,
    match_id            INTEGER NOT NULL REFERENCES matches(id),
    model_run_id        INTEGER NOT NULL REFERENCES model_runs(id),
    prediction_date     TIMESTAMPTZ NOT NULL DEFAULT now(),
    home_win_probability NUMERIC(6,5) NOT NULL,
    away_win_probability NUMERIC(6,5) NOT NULL,
    predicted_winner_team_id INTEGER NOT NULL REFERENCES teams(id),

    CONSTRAINT chk_probabilities_valid CHECK (
        home_win_probability >= 0 AND home_win_probability <= 1
        AND away_win_probability >= 0 AND away_win_probability <= 1
        AND ABS((home_win_probability + away_win_probability) - 1.0) < 0.001
    ),
    CONSTRAINT uq_prediction_per_match_model UNIQUE (match_id, model_run_id)
);

CREATE INDEX idx_predictions_match ON predictions(match_id);

-- -----------------------------------------------------------------------------
-- ingestion_log
-- -----------------------------------------------------------------------------
-- Every rejected/flagged row from either the scraper or a CSV upload lands
-- here instead of being silently dropped or silently imported, matching the
-- project's core "log, never fabricate or silently fix" rule.
-- -----------------------------------------------------------------------------
CREATE TABLE ingestion_log (
    id              SERIAL PRIMARY KEY,
    source          TEXT NOT NULL,          -- "scraper" | "csv_upload"
    source_ref      TEXT,                    -- source_url, or uploaded filename
    raw_row         JSONB,                   -- the offending row, as received
    issue           TEXT NOT NULL,           -- e.g. "NOT_RECOGNIZED_TEAM: ..."
    resolved        BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================================================
-- SQLite notes (if you'd rather run this with zero server setup):
--   - Replace SERIAL with INTEGER PRIMARY KEY AUTOINCREMENT
--   - Replace TIMESTAMPTZ with TEXT (store ISO8601) or NUMERIC
--   - Replace JSONB with TEXT (store JSON as a string)
--   - Replace NUMERIC(p,s) with REAL
--   - CHECK constraints work the same in SQLite
-- =============================================================================
