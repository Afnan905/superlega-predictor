-- =============================================================================
-- SuperLega Predictor — Database Schema (Phase 2) — SQLite version
-- =============================================================================
-- Functionally identical to schema.sql (the Postgres version), translated to
-- SQLite types/syntax. Every constraint (uniqueness, check constraints on
-- valid results, valid probabilities, etc.) was tested and confirmed working
-- in SQLite before this file was finalized.
--
-- USAGE:
--   sqlite3 superlega.db < schema_sqlite.sql
-- or, from Python:
--   import sqlite3
--   conn = sqlite3.connect("superlega.db")
--   conn.executescript(open("schema_sqlite.sql").read())
-- =============================================================================

PRAGMA foreign_keys = ON;

CREATE TABLE teams (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    canonical_name  TEXT NOT NULL UNIQUE,
    abbreviation    TEXT,
    city            TEXT,
    active          INTEGER NOT NULL DEFAULT 1,   -- boolean: 0/1
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE team_name_aliases (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id     INTEGER NOT NULL REFERENCES teams(id),
    alias       TEXT NOT NULL UNIQUE,
    season      TEXT,
    source      TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE seasons (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    start_date  TEXT,
    end_date    TEXT,
    is_current  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE matches (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    season_id       INTEGER NOT NULL REFERENCES seasons(id),
    giornata_label  TEXT,
    date            TEXT,             -- ISO 'YYYY-MM-DD'; NULL if not yet confirmed
    date_is_approximate INTEGER NOT NULL DEFAULT 0,  -- 1 = date came from article publish date, not an explicit match date
    home_team_id    INTEGER NOT NULL REFERENCES teams(id),
    away_team_id    INTEGER NOT NULL REFERENCES teams(id),
    home_sets       INTEGER,          -- nullable: NULL means not yet played (upcoming match)
    away_sets       INTEGER,
    winner_team_id  INTEGER REFERENCES teams(id),
    set_scores      TEXT,
    is_completed    INTEGER NOT NULL DEFAULT 1,
    source          TEXT NOT NULL,
    source_url      TEXT,
    ingested_at     TEXT NOT NULL DEFAULT (datetime('now')),

    -- A completed match MUST have real, valid, non-tied set scores. An
    -- upcoming match (is_completed=0) has NULL scores and skips all
    -- score-related checks — there's nothing to validate yet.
    CHECK (
        is_completed = 0
        OR (home_sets IS NOT NULL AND away_sets IS NOT NULL
            AND home_sets <> away_sets
            AND home_sets BETWEEN 0 AND 3 AND away_sets BETWEEN 0 AND 3)
    ),
    CHECK (home_team_id <> away_team_id),
    UNIQUE (season_id, date, home_team_id, away_team_id)
);

CREATE INDEX idx_matches_season ON matches(season_id);
CREATE INDEX idx_matches_date ON matches(date);
CREATE INDEX idx_matches_home_team ON matches(home_team_id);
CREATE INDEX idx_matches_away_team ON matches(away_team_id);

CREATE TABLE team_match_statistics (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id                INTEGER NOT NULL REFERENCES matches(id),
    team_id                 INTEGER NOT NULL REFERENCES teams(id),
    is_home                 INTEGER NOT NULL,
    points_scored_total     INTEGER,
    attack_points           INTEGER,
    attack_errors           INTEGER,
    attack_efficiency       REAL,
    block_points            INTEGER,
    serve_aces              INTEGER,
    serve_errors            INTEGER,
    reception_positive_pct  REAL,
    reception_perfect_pct   REAL,
    total_errors            INTEGER,
    data_completeness       TEXT NOT NULL DEFAULT 'partial',

    UNIQUE (match_id, team_id)
);

CREATE TABLE match_player_points (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id    INTEGER NOT NULL REFERENCES matches(id),
    team_id     INTEGER NOT NULL REFERENCES teams(id),
    player_name TEXT NOT NULL,
    points      INTEGER
);

CREATE TABLE team_ratings (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id             INTEGER NOT NULL REFERENCES teams(id),
    match_id            INTEGER NOT NULL REFERENCES matches(id),
    rating_before       REAL NOT NULL,
    rating_after        REAL NOT NULL,
    expected_result     REAL,
    actual_result       REAL,
    rating_change       REAL NOT NULL,
    computed_at         TEXT NOT NULL DEFAULT (datetime('now')),

    UNIQUE (team_id, match_id)
);

CREATE INDEX idx_team_ratings_team ON team_ratings(team_id);

CREATE TABLE model_runs (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    model_version     TEXT NOT NULL UNIQUE,
    model_type        TEXT NOT NULL,
    training_date     TEXT NOT NULL,
    training_seasons  TEXT NOT NULL,
    validation_season TEXT,
    test_season       TEXT,
    features          TEXT NOT NULL,     -- JSON-encoded list, stored as text
    accuracy          REAL,
    log_loss          REAL,
    brier_score       REAL,
    num_train_matches INTEGER,
    num_val_matches   INTEGER,
    num_test_matches  INTEGER,
    calibration       TEXT,                -- JSON-encoded calibration bins, see train.py
    notes             TEXT
);

CREATE TABLE predictions (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id                    INTEGER NOT NULL REFERENCES matches(id),
    model_run_id                INTEGER NOT NULL REFERENCES model_runs(id),
    prediction_date              TEXT NOT NULL DEFAULT (datetime('now')),
    home_win_probability        REAL NOT NULL,
    away_win_probability        REAL NOT NULL,
    predicted_winner_team_id    INTEGER NOT NULL REFERENCES teams(id),

    CHECK (
        home_win_probability >= 0 AND home_win_probability <= 1
        AND away_win_probability >= 0 AND away_win_probability <= 1
        AND ABS((home_win_probability + away_win_probability) - 1.0) < 0.001
    ),
    UNIQUE (match_id, model_run_id)
);

CREATE INDEX idx_predictions_match ON predictions(match_id);

CREATE TABLE ingestion_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source          TEXT NOT NULL,        -- 'scraper' | 'csv_upload'
    source_ref      TEXT,
    raw_row         TEXT,                  -- JSON-encoded, stored as text
    issue           TEXT NOT NULL,
    resolved        INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
