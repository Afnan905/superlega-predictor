import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api, type TeamProfile } from "../lib/api";
import StatCard from "../components/StatCard";
import ErrorBanner from "../components/ErrorBanner";

export default function TeamDetail() {
  const { teamName } = useParams<{ teamName: string }>();
  const [profile, setProfile] = useState<TeamProfile | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!teamName) return;
    setProfile(null);
    setError(null);
    api
      .getTeamStats(teamName)
      .then(setProfile)
      .catch((e) => setError(e.message));
  }, [teamName]);

  if (error) {
    return (
      <div className="mx-auto max-w-4xl px-6 py-12">
        <Link to="/teams" className="text-sm text-steel hover:text-match-point">
          ← Back to teams
        </Link>
        <div className="mt-6">
          <ErrorBanner message={error} />
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="mx-auto max-w-4xl px-6 py-12">
        <p className="text-steel">Loading team profile…</p>
      </div>
    );
  }

  const winPct = profile.matches_played > 0 ? profile.wins / profile.matches_played : null;

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <Link to="/teams" className="text-sm text-steel hover:text-match-point">
        ← Back to teams
      </Link>

      <p className="mt-4 font-mono text-xs uppercase tracking-[0.2em] text-match-point">
        Team profile
      </p>
      <h1 className="mt-2 font-display text-5xl tracking-wide text-chalk">{profile.team}</h1>

      <div className="mt-4 flex items-baseline gap-3">
        <span className="font-display text-4xl text-match-point tabular-nums">
          {profile.current_elo.toFixed(0)}
        </span>
        <span className="text-sm text-steel">current Elo rating</span>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard
          label="Overall record"
          value={`${profile.wins}–${profile.losses}`}
          sublabel={winPct != null ? `${Math.round(winPct * 100)}% win rate` : undefined}
        />
        <StatCard
          label="Home record"
          value={`${profile.home_record.wins}–${profile.home_record.losses}`}
        />
        <StatCard
          label="Away record"
          value={`${profile.away_record.wins}–${profile.away_record.losses}`}
        />
        <StatCard
          label="Sets"
          value={`${profile.sets_won}–${profile.sets_lost}`}
          sublabel={`${profile.sets_won - profile.sets_lost >= 0 ? "+" : ""}${
            profile.sets_won - profile.sets_lost
          } differential`}
        />
      </div>

      <div className="mt-8">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-steel">
          Recent form (last 5)
        </h2>
        <div className="mt-3">
          {profile.recent_form_last5.wins != null ? (
            <StatCard
              label="Last 5 matches"
              value={`${profile.recent_form_last5.wins}/5 wins`}
              sublabel={`${
                profile.recent_form_last5.set_diff != null && profile.recent_form_last5.set_diff >= 0
                  ? "+"
                  : ""
              }${profile.recent_form_last5.set_diff} sets`}
            />
          ) : (
            <p className="text-sm text-steel">Not enough match history yet.</p>
          )}
        </div>
      </div>

      <div className="mt-10 rounded-lg border border-court-blue bg-court-blue/20 px-5 py-4">
        <p className="text-sm text-steel">
          Want a prediction involving {profile.team}?{" "}
          <Link to="/predictor" className="text-match-point hover:underline">
            Try the match predictor →
          </Link>
        </p>
      </div>
    </div>
  );
}
