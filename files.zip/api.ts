// API base URL — override via a .env file (VITE_API_BASE_URL=http://localhost:8000)
// if the backend isn't running on the default port. See .env.example.
const API_BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || "http://localhost:8000";

export interface Team {
  id: number;
  canonical_name: string;
  active: boolean;
  aliases: string[];
}

export interface FormStats {
  wins: number | null;
  set_diff: number | null;
}

export interface TeamStats {
  recent_form_last3: FormStats;
  recent_form_last5: FormStats;
  season_win_pct: number | null;
  home_win_pct?: number | null;
  away_win_pct?: number | null;
}

export interface HeadToHead {
  home_wins: number | null;
  away_wins: number | null;
  set_diff: number | null;
}

export interface SupportingStats {
  home: TeamStats;
  away: TeamStats;
  head_to_head: HeadToHead;
}

export interface Prediction {
  home_team: string;
  away_team: string;
  home_win_probability: number;
  away_win_probability: number;
  predicted_winner: string;
  model_version: string;
  prediction_timestamp: string;
  features_used: string[];
  home_current_elo: number;
  away_current_elo: number;
  supporting_stats: SupportingStats;
  disclaimer: string;
}

export interface CalibrationBin {
  bin_range: string;
  n: number;
  avg_predicted: number;
  actual_win_rate: number;
}

export interface ModelRun {
  model_version: string;
  model_type: string;
  training_date: string;
  training_seasons: string;
  validation_season: string | null;
  test_season: string | null;
  accuracy: number | null;
  log_loss: number | null;
  brier_score: number | null;
  num_train_matches: number | null;
  num_val_matches: number | null;
  num_test_matches: number | null;
  calibration: CalibrationBin[] | null;
  notes: string | null;
}

export interface ModelInfo {
  disclaimer: string;
  model_runs: ModelRun[];
}

export interface RecordSplit {
  wins: number;
  losses: number;
}

export interface TeamProfile {
  team: string;
  current_elo: number;
  matches_played: number;
  wins: number;
  losses: number;
  home_record: RecordSplit;
  away_record: RecordSplit;
  sets_won: number;
  sets_lost: number;
  recent_form_last5: FormStats;
}

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}${path}`);
  } catch {
    throw new ApiError(
      `Couldn't reach the prediction server at ${API_BASE_URL}. Is it running?`,
      0
    );
  }
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      if (body?.detail) detail = body.detail;
    } catch {
      // response wasn't JSON — fall back to statusText
    }
    throw new ApiError(detail, res.status);
  }
  return res.json();
}

export interface UpcomingMatch extends Prediction {
  match_id: number;
  date: string;
  giornata_label: string | null;
  season: string;
}

export const api = {
  getTeams: () => request<Team[]>("/api/teams"),
  getPrediction: (homeTeam: string, awayTeam: string) =>
    request<Prediction>(
      `/api/predict/${encodeURIComponent(homeTeam)}/${encodeURIComponent(awayTeam)}`
    ),
  getUpcoming: () => request<UpcomingMatch[]>("/api/upcoming"),
  getTeamStats: (teamName: string) =>
    request<TeamProfile>(`/api/teams/${encodeURIComponent(teamName)}/stats`),
  getModelInfo: () => request<ModelInfo>("/api/model-info"),
};

export { ApiError };
