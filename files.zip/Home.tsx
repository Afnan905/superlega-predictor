import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type ModelInfo, type UpcomingMatch } from "../lib/api";
import StatCard from "../components/StatCard";
import ErrorBanner from "../components/ErrorBanner";
import Scoreboard from "../components/Scoreboard";

export default function Home() {
  const [modelInfo, setModelInfo] = useState<ModelInfo | null>(null);
  const [upcoming, setUpcoming] = useState<UpcomingMatch[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [upcomingError, setUpcomingError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getModelInfo()
      .then(setModelInfo)
      .catch((e) => setError(e.message));
    api
      .getUpcoming()
      .then(setUpcoming)
      .catch((e) => setUpcomingError(e.message));
  }, []);

  const activeModel = modelInfo?.model_runs?.[0];

  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      {/* Hero */}
      <section className="border-b border-court-blue pb-14">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-match-point">
          Italian Men's SuperLega · Machine-Learning Predictions
        </p>
        <h1 className="mt-4 font-display text-6xl leading-[0.95] tracking-wide text-chalk md:text-7xl">
          SUPERLEGA
          <br />
          <span className="text-match-point">PREDICTOR</span>
        </h1>
        <p className="mt-6 max-w-xl text-lg text-steel">
          Machine-learning predictions for the Italian SuperLega, trained on 1,111 real matches
          across four seasons — every prediction traces back to real Elo ratings, real recent
          form, and a model you can inspect.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            to="/predictor"
            className="rounded-lg bg-match-point px-6 py-3 font-semibold text-court-navy transition-transform hover:scale-[1.02]"
          >
            Predict a matchup →
          </Link>
          <Link
            to="/model"
            className="rounded-lg border border-court-blue px-6 py-3 font-semibold text-chalk transition-colors hover:border-match-point"
          >
            See model performance
          </Link>
        </div>
      </section>

      {/* Upcoming matches — real fixtures, not hypothetical */}
      <section className="border-b border-court-blue py-14">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-2xl tracking-wide text-chalk">Upcoming matches</h2>
          {upcoming && upcoming.length > 0 && (
            <span className="font-mono text-xs text-steel">{upcoming[0].season} season</span>
          )}
        </div>

        {upcomingError && <div className="mt-4"><ErrorBanner message={upcomingError} /></div>}
        {!upcomingError && upcoming === null && (
          <p className="mt-4 text-steel">Loading upcoming fixtures…</p>
        )}
        {upcoming && upcoming.length === 0 && (
          <p className="mt-4 text-steel">
            No upcoming fixtures loaded yet.{" "}
            <Link to="/predictor" className="text-match-point hover:underline">
              Try a hypothetical matchup instead →
            </Link>
          </p>
        )}

        {upcoming && upcoming.length > 0 && (
          <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
            {upcoming.map((m) => (
              <div key={m.match_id} className="rounded-xl border border-court-blue bg-court-blue/20 p-5">
                <div className="flex items-center justify-between text-xs text-steel">
                  <span>{m.giornata_label ?? "Upcoming"}</span>
                  <span className="font-mono">
                    {new Date(m.date).toLocaleDateString(undefined, {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                    })}
                  </span>
                </div>
                <div className="mt-3">
                  <Scoreboard prediction={m} compact />
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Model snapshot */}
      <section className="py-14">
        <h2 className="font-display text-2xl tracking-wide text-chalk">
          Current model, at a glance
        </h2>
        {error && <div className="mt-4"><ErrorBanner message={error} /></div>}
        {!error && !modelInfo && (
          <p className="mt-4 text-steel">Loading model performance…</p>
        )}
        {activeModel && (
          <>
            <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
              <StatCard
                label="Model"
                value={activeModel.model_version}
                sublabel={activeModel.model_type.replace("_", " ")}
              />
              <StatCard
                label="Test accuracy"
                value={
                  activeModel.accuracy != null
                    ? `${Math.round(activeModel.accuracy * 100)}%`
                    : "—"
                }
              />
              <StatCard
                label="Log loss"
                value={activeModel.log_loss != null ? activeModel.log_loss.toFixed(3) : "—"}
                sublabel="lower is better"
              />
              <StatCard
                label="Training matches"
                value={activeModel.num_train_matches ?? "—"}
                sublabel={activeModel.training_seasons}
              />
            </div>
            <p className="mt-6 max-w-2xl text-sm text-steel">
              Validated and tested on the {activeModel.validation_season ?? "most recent"} season,
              using a chronological split — the model never sees a match before it's played.{" "}
              <Link to="/model" className="text-match-point hover:underline">
                Full breakdown and calibration →
              </Link>
            </p>
          </>
        )}
      </section>

      {/* Disclaimer, per brief section 25 */}
      <section className="border-t border-court-blue pt-8">
        <p className="max-w-2xl text-sm text-steel">
          {modelInfo?.disclaimer ??
            "This project provides statistical predictions for educational and analytical purposes. Predictions are probabilities, not guarantees."}
        </p>
      </section>
    </div>
  );
}
