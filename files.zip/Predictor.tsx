import { useEffect, useState } from "react";
import { api, type Team, type Prediction, ApiError } from "../lib/api";
import TeamSelect from "../components/TeamSelect";
import Scoreboard from "../components/Scoreboard";
import StatCard from "../components/StatCard";
import ErrorBanner from "../components/ErrorBanner";

function formatForm(form: { wins: number | null; set_diff: number | null }, n: number): string {
  if (form.wins == null) return "No data yet";
  const sign = form.set_diff != null && form.set_diff >= 0 ? "+" : "";
  return `${form.wins}/${n} wins (${sign}${form.set_diff} sets)`;
}

function formatPct(pct: number | null | undefined): string {
  if (pct == null) return "—";
  return `${Math.round(pct * 100)}%`;
}

export default function Predictor() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [homeTeam, setHomeTeam] = useState("");
  const [awayTeam, setAwayTeam] = useState("");
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [teamsError, setTeamsError] = useState<string | null>(null);
  const [predictionError, setPredictionError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api
      .getTeams()
      .then((t) => setTeams(t.filter((team) => team.active)))
      .catch((e) => setTeamsError(e.message));
  }, []);

  async function handlePredict() {
    if (!homeTeam || !awayTeam) return;
    setLoading(true);
    setPredictionError(null);
    setPrediction(null);
    try {
      const result = await api.getPrediction(homeTeam, awayTeam);
      setPrediction(result);
    } catch (e) {
      setPredictionError(e instanceof ApiError ? e.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-match-point">
        Match Predictor
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-wide text-chalk">
        Pick a matchup
      </h1>
      <p className="mt-3 max-w-xl text-steel">
        Choose any two teams to get a live win-probability prediction, using each team's current
        Elo rating, recent form, and head-to-head record.
      </p>

      {teamsError && (
        <div className="mt-6">
          <ErrorBanner message={teamsError} />
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 gap-4 rounded-xl border border-court-blue bg-court-blue/20 p-6 sm:grid-cols-2">
        <TeamSelect label="Home team" teams={teams} value={homeTeam} onChange={setHomeTeam} excludeName={awayTeam} />
        <TeamSelect label="Away team" teams={teams} value={awayTeam} onChange={setAwayTeam} excludeName={homeTeam} />
        <button
          onClick={handlePredict}
          disabled={!homeTeam || !awayTeam || loading}
          className="sm:col-span-2 mt-2 rounded-lg bg-match-point py-3 font-semibold text-court-navy transition-transform hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
        >
          {loading ? "Predicting…" : "Predict this match"}
        </button>
      </div>

      {predictionError && (
        <div className="mt-6">
          <ErrorBanner message={predictionError} />
        </div>
      )}

      {prediction && (
        <div className="mt-10 space-y-8">
          <div className="rounded-xl border border-court-blue bg-court-blue/20 p-8">
            <Scoreboard prediction={prediction} />
          </div>

          <div>
            <h2 className="font-display text-xl tracking-wide text-chalk">Supporting stats</h2>
            <div className="mt-4 grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div className="space-y-3">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-steel">
                  {prediction.home_team}
                </h3>
                <StatCard
                  label="Last 3 matches"
                  value={formatForm(prediction.supporting_stats.home.recent_form_last3, 3)}
                />
                <StatCard
                  label="Last 5 matches"
                  value={formatForm(prediction.supporting_stats.home.recent_form_last5, 5)}
                />
                <StatCard
                  label="Season win rate"
                  value={formatPct(prediction.supporting_stats.home.season_win_pct)}
                />
                <StatCard
                  label="Home win rate"
                  value={formatPct(prediction.supporting_stats.home.home_win_pct)}
                />
              </div>
              <div className="space-y-3">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-steel">
                  {prediction.away_team}
                </h3>
                <StatCard
                  label="Last 3 matches"
                  value={formatForm(prediction.supporting_stats.away.recent_form_last3, 3)}
                />
                <StatCard
                  label="Last 5 matches"
                  value={formatForm(prediction.supporting_stats.away.recent_form_last5, 5)}
                />
                <StatCard
                  label="Season win rate"
                  value={formatPct(prediction.supporting_stats.away.season_win_pct)}
                />
                <StatCard
                  label="Away win rate"
                  value={formatPct(prediction.supporting_stats.away.away_win_pct)}
                />
              </div>
            </div>

            <div className="mt-4">
              <StatCard
                label="Head-to-head"
                value={
                  prediction.supporting_stats.head_to_head.home_wins != null
                    ? `${prediction.supporting_stats.head_to_head.home_wins}–${prediction.supporting_stats.head_to_head.away_wins}`
                    : "No prior meetings"
                }
                sublabel={`${prediction.home_team} record vs ${prediction.away_team}`}
              />
            </div>
          </div>

          <div>
            <h2 className="font-display text-xl tracking-wide text-chalk">
              What the model used
            </h2>
            <p className="mt-2 text-sm text-steel">
              This prediction is based on {prediction.features_used.length} features computed
              from real match history — Elo rating difference, recent form, season performance,
              and head-to-head record. No factor here is invented; every number traces back to a
              completed match.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {prediction.features_used.map((f) => (
                <span
                  key={f}
                  className="rounded-full border border-court-blue bg-court-blue/40 px-3 py-1 font-mono text-xs text-steel"
                >
                  {f}
                </span>
              ))}
            </div>
          </div>

          <p className="border-t border-court-blue pt-6 text-xs text-steel">
            {prediction.disclaimer} Predicted{" "}
            {new Date(prediction.prediction_timestamp).toLocaleString()} using model{" "}
            {prediction.model_version}.
          </p>
        </div>
      )}
    </div>
  );
}
