import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type Team } from "../lib/api";
import ErrorBanner from "../components/ErrorBanner";

export default function Teams() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getTeams()
      .then(setTeams)
      .catch((e) => setError(e.message));
  }, []);

  const active = teams.filter((t) => t.active);
  const inactive = teams.filter((t) => !t.active);

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-match-point">Teams</p>
      <h1 className="mt-2 font-display text-4xl tracking-wide text-chalk">SuperLega clubs</h1>
      <p className="mt-3 max-w-xl text-steel">
        Every club with real match history in the database, across all four tracked seasons.
      </p>

      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} />
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
        {active.map((team) => (
          <Link
            key={team.id}
            to={`/teams/${encodeURIComponent(team.canonical_name)}`}
            className="group rounded-lg border border-court-blue bg-court-blue/20 px-5 py-4 transition-colors hover:border-match-point hover:bg-court-blue/40"
          >
            <div className="font-semibold text-chalk group-hover:text-match-point">
              {team.canonical_name}
            </div>
            {team.aliases.length > 0 && (
              <div className="mt-1 text-xs text-steel">
                also: {team.aliases.slice(0, 2).join(", ")}
                {team.aliases.length > 2 ? "…" : ""}
              </div>
            )}
          </Link>
        ))}
      </div>

      {inactive.length > 0 && (
        <div className="mt-10">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-steel">
            No longer in SuperLega
          </h2>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
            {inactive.map((team) => (
              <Link
                key={team.id}
                to={`/teams/${encodeURIComponent(team.canonical_name)}`}
                className="rounded-lg border border-court-blue/50 bg-court-blue/10 px-5 py-4 opacity-70 transition-opacity hover:opacity-100"
              >
                <div className="font-semibold text-chalk">{team.canonical_name}</div>
                <div className="mt-1 text-xs text-steel">Historical data only</div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
