import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Predictor from "./pages/Predictor";
import Predictions from "./pages/Predictions";
import Teams from "./pages/Teams";
import TeamDetail from "./pages/TeamDetail";
import ModelPerformance from "./pages/ModelPerformance";

export default function App() {
  return (
    <div className="min-h-screen bg-court-navy">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/predictor" element={<Predictor />} />
          <Route path="/predictions" element={<Predictions />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/teams/:teamName" element={<TeamDetail />} />
          <Route path="/model" element={<ModelPerformance />} />
          <Route
            path="*"
            element={
              <div className="mx-auto max-w-4xl px-6 py-24 text-center">
                <p className="font-display text-3xl text-chalk">Page not found</p>
                <p className="mt-2 text-steel">Try one of the links above.</p>
              </div>
            }
          />
        </Routes>
      </main>
      <footer className="border-t border-court-blue px-6 py-8 text-center text-xs text-steel">
        SuperLega Predictor — built on real match data, not vibes.
      </footer>
    </div>
  );
}
