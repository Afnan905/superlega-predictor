import type { Prediction } from "../lib/api";

interface ScoreboardProps {
  prediction: Prediction;
  compact?: boolean;
}

/**
 * The signature element of the SuperLega Predictor: a scoreboard-style
 * split showing each team's win probability as a big, tabular-numeral
 * percentage with a proportional bar beneath — evoking a broadcast
 * pre-match graphic rather than a generic dashboard progress bar.
 */
export default function Scoreboard({ prediction, compact = false }: ScoreboardProps) {
  const homePct = Math.round(prediction.home_win_probability * 100);
  const awayPct = 100 - homePct;
  const homeIsWinner = prediction.predicted_winner === prediction.home_team;

  const numberSize = compact ? "text-5xl" : "text-7xl md:text-8xl";
  const nameSize = compact ? "text-sm" : "text-lg";

  return (
    <div className="w-full">
      <div className="grid grid-cols-2 gap-4">
        <div className="text-left">
          <div className={`${nameSize} font-semibold uppercase tracking-wide text-chalk`}>
            {prediction.home_team}
          </div>
          <div className="font-mono text-xs text-steel">
            Elo {prediction.home_current_elo.toFixed(0)}
          </div>
          <div
            className={`${numberSize} font-display leading-none tabular-nums ${
              homeIsWinner ? "text-match-point" : "text-steel"
            }`}
          >
            {homePct}
            <span className="text-2xl align-top">%</span>
          </div>
        </div>
        <div className="text-right">
          <div className={`${nameSize} font-semibold uppercase tracking-wide text-chalk`}>
            {prediction.away_team}
          </div>
          <div className="font-mono text-xs text-steel">
            Elo {prediction.away_current_elo.toFixed(0)}
          </div>
          <div
            className={`${numberSize} font-display leading-none tabular-nums ${
              !homeIsWinner ? "text-match-point" : "text-steel"
            }`}
          >
            {awayPct}
            <span className="text-2xl align-top">%</span>
          </div>
        </div>
      </div>

      <div className="mt-4 flex h-2 w-full overflow-hidden rounded-full bg-court-blue">
        <div
          className={`h-full transition-all ${homeIsWinner ? "bg-match-point" : "bg-steel"}`}
          style={{ width: `${homePct}%` }}
        />
        <div
          className={`h-full transition-all ${!homeIsWinner ? "bg-match-point" : "bg-steel"}`}
          style={{ width: `${awayPct}%` }}
        />
      </div>

      <div className="mt-3 flex items-center justify-between text-xs text-steel">
        <span>
          Predicted winner:{" "}
          <span className="font-semibold text-match-point">{prediction.predicted_winner}</span>
        </span>
        <span className="font-mono">{prediction.model_version}</span>
      </div>
    </div>
  );
}
