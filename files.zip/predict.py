"""
predict.py

Given two team names, computes their CURRENT features (as of "now" — i.e.
using every completed match on record) and returns a win-probability
prediction from the deployed model.

This reuses the exact same feature-computation logic as features.py (same
functions, same semantics) so the features fed to the model at prediction
time are computed identically to how they were computed at training time —
critical, since a model's learned weights are only valid for the feature
distribution it was trained on.

USAGE:
    from predict import predict_match
    result = predict_match("Perugia", "Piacenza")
"""

import sqlite3
from datetime import datetime, timezone
from typing import Optional

import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression

from features import (
    _team_prior_matches, _recent_form, _season_win_pct, _head_to_head,
    build_features, load_matches_from_db, FEATURE_COLUMNS,
)
from elo import compute_elo_ratings, INITIAL_RATING

DB_PATH = "superlega.db"
MODEL_PATH = "deployed_model.pkl"

DISCLAIMER = (
    "This project provides statistical predictions for educational and "
    "analytical purposes. Predictions are probabilities, not guarantees."
)

_deployed_model_cache = None


def _train_deployed_model(db_path: str = DB_PATH):
    """
    Trains the deployed model fresh, in memory, from the database — rather
    than loading a pickled model file. This avoids scikit-learn pickle
    version-compatibility issues entirely (a real problem hit in practice:
    a model pickled with sklearn 1.8.0 failed to load under sklearn 1.6.1
    in a different environment). Training on ~1,100 matches with logistic
    regression takes well under a second, so there's no real cost to doing
    this at startup instead of shipping a binary artifact.

    Trains on ALL available historical matches (not just the 2022-24
    seasons used for the train/val/test evaluation split) — for an actual
    deployed prediction model, using every real result on hand is the right
    call; the held-out evaluation split remains valid and unchanged for
    reporting metrics (see train.py), this is a separate, appropriately
    different use of the same data.
    """
    global _deployed_model_cache
    if _deployed_model_cache is not None:
        return _deployed_model_cache

    matches = load_matches_from_db(db_path)
    features = build_features(matches)

    import pandas as pd
    df = pd.DataFrame([f.__dict__ for f in features])

    X_raw = df[FEATURE_COLUMNS].to_numpy(dtype=float)
    y = df["home_won"].to_numpy(dtype=int)

    imputer = SimpleImputer(strategy="mean")
    X = imputer.fit_transform(X_raw)

    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)

    _deployed_model_cache = {
        "model": model, "imputer": imputer,
        "feature_columns": FEATURE_COLUMNS, "model_version": "logreg-v1",
    }
    return _deployed_model_cache


def _resolve_team(conn: sqlite3.Connection, name: str) -> Optional[dict]:
    """Case-insensitive lookup against canonical team names and aliases.
    Returns {'id': ..., 'canonical_name': ...} or None if not found."""
    row = conn.execute(
        "SELECT id, canonical_name FROM teams WHERE LOWER(canonical_name) = LOWER(?)",
        (name,),
    ).fetchone()
    if row:
        return {"id": row[0], "canonical_name": row[1]}

    row = conn.execute(
        """SELECT t.id, t.canonical_name FROM teams t
           JOIN team_name_aliases a ON a.team_id = t.id
           WHERE LOWER(a.alias) = LOWER(?)""",
        (name,),
    ).fetchone()
    if row:
        return {"id": row[0], "canonical_name": row[1]}

    return None


def _load_all_matches(conn: sqlite3.Connection) -> list:
    """
    Loads COMPLETED matches only — this is historical input for computing
    a team's current Elo/form, never the thing being predicted. Upcoming
    matches (is_completed=0, NULL scores) must never appear here: feeding
    a match with no real result into Elo computation would compare NoneType
    scores and crash, and conceptually an unplayed match isn't "history"
    regardless.
    """
    rows = conn.execute("""
        SELECT id AS match_id, date, home_team_id, away_team_id, home_sets, away_sets
        FROM matches WHERE date IS NOT NULL AND is_completed = 1
        ORDER BY date, id
    """).fetchall()
    return [
        {"match_id": r[0], "date": r[1], "home_team_id": r[2], "away_team_id": r[3],
         "home_sets": r[4], "away_sets": r[5]}
        for r in rows
    ]


def _current_elo(all_matches: list, team_id: int) -> float:
    """The team's rating AFTER its most recent completed match, or the
    initial default rating if it has no match history at all."""
    records = compute_elo_ratings(all_matches)
    team_records = [r for r in records if r.team_id == team_id]
    if not team_records:
        return INITIAL_RATING
    return team_records[-1].rating_after


def get_team_profile(team_name: str, db_path: str = DB_PATH) -> dict:
    """
    Computes a team's current stats — Elo, overall/home/away record, recent
    form — using the same helper functions predict_match() uses, just for
    one team rather than a head-to-head pair. Powers the Teams page.
    """
    conn = sqlite3.connect(db_path)
    team = _resolve_team(conn, team_name)
    if team is None:
        conn.close()
        raise ValueError(f"Unknown team: '{team_name}'")

    all_matches = _load_all_matches(conn)
    conn.close()

    now = datetime.now(timezone.utc).date().isoformat()
    team_matches = _team_prior_matches(all_matches, team["id"], now)

    wins = sum(
        1 for m in team_matches
        if (m["home_team_id"] == team["id"] and m["home_sets"] > m["away_sets"])
        or (m["away_team_id"] == team["id"] and m["away_sets"] > m["home_sets"])
    )
    home_matches = [m for m in team_matches if m["home_team_id"] == team["id"]]
    away_matches = [m for m in team_matches if m["away_team_id"] == team["id"]]
    home_wins = sum(1 for m in home_matches if m["home_sets"] > m["away_sets"])
    away_wins = sum(1 for m in away_matches if m["away_sets"] > m["home_sets"])
    sets_won = sum(
        m["home_sets"] if m["home_team_id"] == team["id"] else m["away_sets"]
        for m in team_matches
    )
    sets_lost = sum(
        m["away_sets"] if m["home_team_id"] == team["id"] else m["home_sets"]
        for m in team_matches
    )

    last5_w, last5_sd = _recent_form(all_matches, team["id"], now, 5)
    current_elo = _current_elo(all_matches, team["id"])

    return {
        "team": team["canonical_name"],
        "current_elo": round(current_elo, 1),
        "matches_played": len(team_matches),
        "wins": wins,
        "losses": len(team_matches) - wins,
        "home_record": {"wins": home_wins, "losses": len(home_matches) - home_wins},
        "away_record": {"wins": away_wins, "losses": len(away_matches) - away_wins},
        "sets_won": sets_won,
        "sets_lost": sets_lost,
        "recent_form_last5": {"wins": last5_w, "set_diff": last5_sd},
    }


def get_upcoming_predictions(db_path: str = DB_PATH) -> list:
    """
    Lists every upcoming (not yet played) match on record, each with a live
    prediction computed from current team state. This is what distinguishes
    completed matches from upcoming ones (brief section 12) and is what
    powers a real "upcoming matches" view rather than a hypothetical
    matchup builder.
    """
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("""
        SELECT m.id, m.date, m.giornata_label, ht.canonical_name AS home_team,
               at.canonical_name AS away_team, s.name AS season
        FROM matches m
        JOIN teams ht ON m.home_team_id = ht.id
        JOIN teams at ON m.away_team_id = at.id
        JOIN seasons s ON m.season_id = s.id
        WHERE m.is_completed = 0
        ORDER BY m.date, m.id
    """).fetchall()
    conn.close()

    results = []
    for row in rows:
        pred = predict_match(row["home_team"], row["away_team"], db_path=db_path)
        results.append({
            "match_id": row["id"],
            "date": row["date"],
            "giornata_label": row["giornata_label"],
            "season": row["season"],
            **pred,
        })
    return results


def predict_match(home_team_name: str, away_team_name: str, model_path: str = MODEL_PATH,
                   db_path: str = DB_PATH) -> dict:
    conn = sqlite3.connect(db_path)

    home = _resolve_team(conn, home_team_name)
    away = _resolve_team(conn, away_team_name)

    if home is None:
        conn.close()
        raise ValueError(f"Unknown team: '{home_team_name}'")
    if away is None:
        conn.close()
        raise ValueError(f"Unknown team: '{away_team_name}'")
    if home["id"] == away["id"]:
        conn.close()
        raise ValueError("home_team and away_team must be different teams")

    all_matches = _load_all_matches(conn)
    conn.close()

    # "Now" is later than every match on record, so this naturally includes
    # a team's full history — same _recent_form/_season_win_pct/_head_to_head
    # functions used at training time, just with a "before_date" that's
    # effectively "today" rather than a specific past match's date.
    now = datetime.now(timezone.utc).date().isoformat()

    home_elo = _current_elo(all_matches, home["id"])
    away_elo = _current_elo(all_matches, away["id"])

    h_last3_w, h_last3_sd = _recent_form(all_matches, home["id"], now, 3)
    h_last5_w, h_last5_sd = _recent_form(all_matches, home["id"], now, 5)
    a_last3_w, a_last3_sd = _recent_form(all_matches, away["id"], now, 3)
    a_last5_w, a_last5_sd = _recent_form(all_matches, away["id"], now, 5)

    home_season_pct = _season_win_pct(all_matches, home["id"], now)
    away_season_pct = _season_win_pct(all_matches, away["id"], now)
    home_home_pct = _season_win_pct(all_matches, home["id"], now, home_only=True)
    away_away_pct = _season_win_pct(all_matches, away["id"], now, home_only=False)

    h2h_home_w, h2h_away_w, h2h_sd = _head_to_head(all_matches, home["id"], away["id"], now)

    feature_row = {
        "elo_diff": home_elo - away_elo,
        "home_last3_wins": h_last3_w, "home_last5_wins": h_last5_w,
        "away_last3_wins": a_last3_w, "away_last5_wins": a_last5_w,
        "home_last3_set_diff": h_last3_sd, "home_last5_set_diff": h_last5_sd,
        "away_last3_set_diff": a_last3_sd, "away_last5_set_diff": a_last5_sd,
        "home_season_win_pct": home_season_pct, "away_season_win_pct": away_season_pct,
        "home_home_win_pct": home_home_pct, "away_away_win_pct": away_away_pct,
        "h2h_home_wins": h2h_home_w, "h2h_away_wins": h2h_away_w, "h2h_set_diff": h2h_sd,
    }

    bundle = _train_deployed_model(db_path)
    model = bundle["model"]
    imputer = bundle["imputer"]
    feature_columns = bundle["feature_columns"]
    model_version = bundle["model_version"]

    X_raw = np.array([[feature_row[col] if feature_row[col] is not None else np.nan
                        for col in feature_columns]], dtype=float)
    X = imputer.transform(X_raw)

    proba = model.predict_proba(X)[0]
    home_win_probability = float(proba[1])
    away_win_probability = float(proba[0])
    predicted_winner = home["canonical_name"] if home_win_probability >= 0.5 else away["canonical_name"]

    return {
        "home_team": home["canonical_name"],
        "away_team": away["canonical_name"],
        "home_win_probability": round(home_win_probability, 4),
        "away_win_probability": round(away_win_probability, 4),
        "predicted_winner": predicted_winner,
        "model_version": model_version,
        "prediction_timestamp": datetime.now(timezone.utc).isoformat(),
        "features_used": feature_columns,
        "home_current_elo": round(home_elo, 1),
        "away_current_elo": round(away_elo, 1),
        "supporting_stats": {
            "home": {
                "recent_form_last3": {"wins": h_last3_w, "set_diff": h_last3_sd},
                "recent_form_last5": {"wins": h_last5_w, "set_diff": h_last5_sd},
                "season_win_pct": round(home_season_pct, 3) if home_season_pct is not None else None,
                "home_win_pct": round(home_home_pct, 3) if home_home_pct is not None else None,
            },
            "away": {
                "recent_form_last3": {"wins": a_last3_w, "set_diff": a_last3_sd},
                "recent_form_last5": {"wins": a_last5_w, "set_diff": a_last5_sd},
                "season_win_pct": round(away_season_pct, 3) if away_season_pct is not None else None,
                "away_win_pct": round(away_away_pct, 3) if away_away_pct is not None else None,
            },
            "head_to_head": {
                "home_wins": h2h_home_w, "away_wins": h2h_away_w, "set_diff": h2h_sd,
            },
        },
        "disclaimer": DISCLAIMER,
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python predict.py <home_team> <away_team>")
        sys.exit(1)
    result = predict_match(sys.argv[1], sys.argv[2])
    import json
    print(json.dumps(result, indent=2, ensure_ascii=False))
