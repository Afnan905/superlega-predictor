import { useEffect, useState } from "react";
import { api, type ModelInfo, type ModelRun } from "../lib/api";
import StatCard from "../components/StatCard";
import ErrorBanner from "../components/ErrorBanner";

function CalibrationChart({ run }: { run: ModelRun }) {
  if (!run.calibration || run.calibration.length === 0) {
    return <p className="text-sm text-steel">No calibration data recorded for this model.</p>;
  }
  return (
    <div className="mt-4 space-y-2">
      {run.calibration.map((bin) => {
        const predicted = Math.round(bin.avg_predicted * 100);
        const actual = Math.round(bin.actual_win_rate * 100);
        const gap = Math.abs(predicted - actual);
        return (
          <div key={bin.bin_range} className="flex items-center gap-3">
            <span className="w-20 shrink-0 font-mono text-xs text-steel">{bin.bin_range}</span>
            <div className="relative h-6 flex-1 rounded bg-court-blue">
              <div
                className="absolute inset-y-0 left-0 rounded bg-court-blue-light"
                style={{ width: `${predicted}%` }}
              />
              <div
                className="absolute inset-y-0 left-0 w-0.5 bg-match-point"
                style={{ left: `${actual}%` }}
                title={`Actual win rate: ${actual}%`}
              />
            </div>
            <span className="w-24 shrink-0 font-mono text-xs text-steel">
              {predicted}% pred · {actual}% actual
            </span>
            <span className="w-14 shrink-0 font-mono text-xs text-steel">n={bin.n}</span>
            {gap > 15 && (
              <span className="rounded bg-match-point/20 px-1.5 py-0.5 text-[10px] text-match-point">
                {gap}pt gap
              </span>
            )}
          </div>
        );
      })}
      <p className="mt-3 text-xs text-steel">
        Blue bar = average predicted probability in this range. Orange tick = the actual win rate
        of matches that fell in that range. Close alignment means the model's confidence is
        trustworthy; a wide gap means predictions in that range shouldn't be read too literally —
        both are shown honestly, not smoothed over.
      </p>
    </div>
  );
}

export default function ModelPerformance() {
  const [modelInfo, setModelInfo] = useState<ModelInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getModelInfo()
      .then(setModelInfo)
      .catch((e) => setError(e.message));
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-match-point">
        Model Performance
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-wide text-chalk">
        How well does it actually predict?
      </h1>
      <p className="mt-3 max-w-xl text-steel">
        Every model trained on this data, evaluated on a held-out chronological split — the
        model never sees a match before it happened. Numbers here are real, not projected.
      </p>

      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} />
        </div>
      )}
      {!error && !modelInfo && <p className="mt-6 text-steel">Loading…</p>}

      {modelInfo && modelInfo.model_runs.length === 0 && (
        <p className="mt-6 text-steel">No trained models on record yet.</p>
      )}

      <div className="mt-10 space-y-10">
        {modelInfo?.model_runs.map((run, i) => (
          <div
            key={run.model_version}
            className="rounded-xl border border-court-blue bg-court-blue/20 p-6"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl tracking-wide text-chalk">
                {run.model_version}
                {i === 0 && (
                  <span className="ml-3 rounded-full bg-ace/20 px-2.5 py-0.5 align-middle text-xs font-sans font-semibold text-ace">
                    Deployed
                  </span>
                )}
              </h2>
              <span className="font-mono text-xs text-steel">
                {run.model_type.replace("_", " ")}
              </span>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <StatCard
                label="Accuracy"
                value={run.accuracy != null ? `${Math.round(run.accuracy * 100)}%` : "—"}
              />
              <StatCard
                label="Log loss"
                value={run.log_loss != null ? run.log_loss.toFixed(3) : "—"}
                sublabel="lower is better"
              />
              <StatCard
                label="Brier score"
                value={run.brier_score != null ? run.brier_score.toFixed(3) : "—"}
                sublabel="lower is better"
              />
              <StatCard label="Test matches" value={run.num_test_matches ?? "—"} />
            </div>

            <div className="mt-6 grid grid-cols-1 gap-3 text-sm text-steel sm:grid-cols-3">
              <div>
                <span className="text-xs uppercase tracking-wide text-steel">Trained on</span>
                <div className="mt-0.5 text-chalk">{run.training_seasons}</div>
                <div className="font-mono text-xs">{run.num_train_matches} matches</div>
              </div>
              <div>
                <span className="text-xs uppercase tracking-wide text-steel">Validated on</span>
                <div className="mt-0.5 text-chalk">{run.validation_season ?? "—"}</div>
                <div className="font-mono text-xs">{run.num_val_matches} matches</div>
              </div>
              <div>
                <span className="text-xs uppercase tracking-wide text-steel">Tested on</span>
                <div className="mt-0.5 text-chalk">{run.test_season ?? "—"}</div>
                <div className="font-mono text-xs">{run.num_test_matches} matches</div>
              </div>
            </div>

            <div className="mt-6 border-t border-court-blue pt-5">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-steel">
                Calibration
              </h3>
              <CalibrationChart run={run} />
            </div>

            {run.notes && (
              <p className="mt-5 border-t border-court-blue pt-4 text-xs text-steel">
                {run.notes}
              </p>
            )}
          </div>
        ))}
      </div>

      {modelInfo && modelInfo.model_runs.length > 1 && (
        <div className="mt-10 rounded-lg border border-court-blue bg-court-blue/20 px-5 py-4">
          <p className="text-sm text-steel">
            <span className="font-semibold text-chalk">Why isn't the fancier model deployed? </span>
            More complex models aren't automatically better — the deployed model is whichever one
            actually wins on held-out test data, checked here rather than assumed.
          </p>
        </div>
      )}

      <p className="mt-10 border-t border-court-blue pt-6 text-xs text-steel">
        {modelInfo?.disclaimer}
      </p>
    </div>
  );
}
