import { useEffect, useState } from "react";
import { api, type Team, type Prediction } from "../lib/api";
import TeamSelect from "../components/TeamSelect";
import ErrorBanner from "../components/ErrorBanner";

type SortKey = "match" | "homeProb" | "awayProb" | "prediction";

export default function Predictions() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [homeTeam, setHomeTeam] = useState("");
  const [awayTeam, setAwayTeam] = useState("");
  const [rows, setRows] = useState<Prediction[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>("homeProb");
  const [sortDesc, setSortDesc] = useState(true);

  useEffect(() => {
    api
      .getTeams()
      .then((t) => setTeams(t.filter((team) => team.active)))
      .catch((e) => setError(e.message));
  }, []);

  async function addMatchup() {
    if (!homeTeam || !awayTeam) return;
    setAdding(true);
    setError(null);
    try {
      const result = await api.getPrediction(homeTeam, awayTeam);
      setRows((prev) => [...prev.filter((r) => !(r.home_team === result.home_team && r.away_team === result.away_team)), result]);
      setHomeTeam("");
      setAwayTeam("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't add that matchup.");
    } finally {
      setAdding(false);
    }
  }

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDesc((d) => !d);
    } else {
      setSortKey(key);
      setSortDesc(true);
    }
  }

  const sorted = [...rows].sort((a, b) => {
    let cmp = 0;
    if (sortKey === "match") cmp = a.home_team.localeCompare(b.home_team);
    if (sortKey === "homeProb") cmp = a.home_win_probability - b.home_win_probability;
    if (sortKey === "awayProb") cmp = a.away_win_probability - b.away_win_probability;
    if (sortKey === "prediction") cmp = a.predicted_winner.localeCompare(b.predicted_winner);
    return sortDesc ? -cmp : cmp;
  });

  const headerButton = (key: SortKey, label: string) => (
    <button
      onClick={() => toggleSort(key)}
      className={`flex items-center gap-1 text-xs font-semibold uppercase tracking-wide transition-colors ${
        sortKey === key ? "text-match-point" : "text-steel hover:text-chalk"
      }`}
    >
      {label}
      {sortKey === key && <span>{sortDesc ? "↓" : "↑"}</span>}
    </button>
  );

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-match-point">Predictions</p>
      <h1 className="mt-2 font-display text-4xl tracking-wide text-chalk">
        Compare matchups
      </h1>
      <p className="mt-3 max-w-xl text-steel">
        Add any matchups you want to compare side by side, sortable by probability. Once the
        2026-27 fixture list is loaded, this table will populate automatically from the real
        upcoming schedule — for now, build your own comparison below.
      </p>

      <div className="mt-8 flex flex-col gap-4 rounded-xl border border-court-blue bg-court-blue/20 p-6 sm:flex-row sm:items-end">
        <div className="flex-1">
          <TeamSelect label="Home team" teams={teams} value={homeTeam} onChange={setHomeTeam} excludeName={awayTeam} />
        </div>
        <div className="flex-1">
          <TeamSelect label="Away team" teams={teams} value={awayTeam} onChange={setAwayTeam} excludeName={homeTeam} />
        </div>
        <button
          onClick={addMatchup}
          disabled={!homeTeam || !awayTeam || adding}
          className="rounded-lg bg-match-point px-6 py-2.5 font-semibold text-court-navy transition-transform hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
        >
          {adding ? "Adding…" : "Add to table"}
        </button>
      </div>

      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} />
        </div>
      )}

      {rows.length === 0 ? (
        <div className="mt-10 rounded-lg border border-dashed border-court-blue px-6 py-12 text-center text-steel">
          No matchups added yet. Pick two teams above to start building your comparison table.
        </div>
      ) : (
        <div className="mt-10 overflow-x-auto rounded-xl border border-court-blue">
          <table className="w-full text-left">
            <thead className="border-b border-court-blue bg-court-blue/30">
              <tr>
                <th className="px-4 py-3">{headerButton("match", "Match")}</th>
                <th className="px-4 py-3">{headerButton("homeProb", "Home %")}</th>
                <th className="px-4 py-3">{headerButton("awayProb", "Away %")}</th>
                <th className="px-4 py-3">{headerButton("prediction", "Predicted winner")}</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {sorted.map((r) => (
                <tr
                  key={`${r.home_team}-${r.away_team}`}
                  className="border-b border-court-blue/50 last:border-0 hover:bg-court-blue/20"
                >
                  <td className="px-4 py-3 text-sm text-chalk">
                    {r.home_team} <span className="text-steel">vs</span> {r.away_team}
                  </td>
                  <td className="px-4 py-3 font-mono text-sm tabular-nums text-chalk">
                    {Math.round(r.home_win_probability * 100)}%
                  </td>
                  <td className="px-4 py-3 font-mono text-sm tabular-nums text-chalk">
                    {Math.round(r.away_win_probability * 100)}%
                  </td>
                  <td className="px-4 py-3 text-sm font-semibold text-match-point">
                    {r.predicted_winner}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() =>
                        setRows((prev) =>
                          prev.filter((row) => !(row.home_team === r.home_team && row.away_team === r.away_team))
                        )
                      }
                      className="text-xs text-steel hover:text-match-point"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
