"""
main.py

SuperLega Predictor — Prediction API (Phase 8).

Exposes:
    GET /api/predict/{home_team}/{away_team}
    GET /api/teams
    GET /api/model-info

USAGE:
    pip install fastapi uvicorn scikit-learn pandas numpy
    uvicorn main:app --reload

Requires (in the same folder, or adjust paths below):
    superlega.db, deployed_model.pkl, plus ml/features.py and ml/elo.py
    importable (see sys.path adjustment below).
"""

import json
import sqlite3
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from predict import predict_match, get_team_profile, get_upcoming_predictions, DISCLAIMER  # noqa: E402

# NOTE: flat paths — upload main.py, predict.py, elo.py, features.py,
# superlega.db, and deployed_model.pkl all into the SAME folder (no
# subfolders needed). This matches train.py's flat-path convention.
DB_PATH = "superlega.db"
MODEL_PATH = "deployed_model.pkl"

app = FastAPI(
    title="SuperLega Predictor API",
    description="Machine-learning win-probability predictions for the Italian SuperLega.",
    version="1.0.0",
)

# Frontend will run on a different origin during development — allow it.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


class TeamStats(BaseModel):
    recent_form_last3: dict
    recent_form_last5: dict
    season_win_pct: Optional[float] = None
    home_win_pct: Optional[float] = None
    away_win_pct: Optional[float] = None


class HeadToHead(BaseModel):
    home_wins: Optional[int] = None
    away_wins: Optional[int] = None
    set_diff: Optional[int] = None


class SupportingStats(BaseModel):
    home: TeamStats
    away: TeamStats
    head_to_head: HeadToHead


class PredictionResponse(BaseModel):
    home_team: str
    away_team: str
    home_win_probability: float
    away_win_probability: float
    predicted_winner: str
    model_version: str
    prediction_timestamp: str
    features_used: list
    home_current_elo: float
    away_current_elo: float
    supporting_stats: SupportingStats
    disclaimer: str


@app.get("/api/predict/{home_team}/{away_team}", response_model=PredictionResponse)
def get_prediction(home_team: str, away_team: str):
    """
    Predicts the outcome of a match between two teams using their current
    form (Elo, recent results, head-to-head, etc. as of right now).
    Team names can be canonical names or any known sponsor alias, matched
    case-insensitively (e.g. both "Perugia" won't resolve, but
    "Sir Susa Scai Perugia" or "Sir Sicoma Monini Perugia" will).
    """
    try:
        result = predict_match(home_team, away_team, model_path=MODEL_PATH, db_path=DB_PATH)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return result


@app.get("/api/teams")
def list_teams():
    """Lists every known team (canonical name) and its known aliases —
    useful for a frontend building a team-picker dropdown."""
    conn = sqlite3.connect(DB_PATH)
    teams = conn.execute("SELECT id, canonical_name, active FROM teams ORDER BY canonical_name").fetchall()
    result = []
    for team_id, name, active in teams:
        aliases = [r[0] for r in conn.execute(
            "SELECT alias FROM team_name_aliases WHERE team_id = ?", (team_id,)
        ).fetchall()]
        result.append({"id": team_id, "canonical_name": name, "active": bool(active), "aliases": aliases})
    conn.close()
    return result


@app.get("/api/upcoming")
def upcoming_matches():
    """Every upcoming (not yet played) match on record, each with a live
    prediction — distinguishes completed matches from upcoming ones per
    brief section 12."""
    return get_upcoming_predictions(db_path=DB_PATH)


@app.get("/api/teams/{team_name}/stats")
def team_stats(team_name: str):
    """Current record, Elo rating, home/away splits, and recent form for
    one team — powers the Teams page's per-team profile."""
    try:
        return get_team_profile(team_name, db_path=DB_PATH)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/model-info")
def model_info():
    """Transparency endpoint (brief section 25): current deployed model
    version, training period, and evaluation metrics from the most recent
    training run — so predictions can be traced back to how the model was
    built and validated."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("""
        SELECT model_version, model_type, training_date, training_seasons,
               validation_season, test_season, accuracy, log_loss, brier_score,
               num_train_matches, num_val_matches, num_test_matches, calibration, notes
        FROM model_runs ORDER BY training_date DESC
    """).fetchall()
    conn.close()

    def parse_row(r):
        d = dict(r)
        if d.get("calibration"):
            d["calibration"] = json.loads(d["calibration"])
        return d

    return {
        "disclaimer": DISCLAIMER,
        "model_runs": [parse_row(r) for r in rows],
    }


@app.get("/")
def root():
    return {
        "name": "SuperLega Predictor API",
        "endpoints": ["/api/predict/{home_team}/{away_team}", "/api/teams", "/api/model-info"],
        "disclaimer": DISCLAIMER,
    }
